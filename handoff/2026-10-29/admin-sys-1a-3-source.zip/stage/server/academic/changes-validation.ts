import { validationDetails } from "../validation-details.js";
import {placementReferences,hasPlacementReferences} from "./references.js";
import { z } from "zod";
import { AuthError } from "../auth/service.js";
import { today } from "../scholars/validation.js";
import type { Placement } from "./changes-model.js";
const text = (min: number, max: number) =>
  z
    .string()
    .trim()
    .min(min)
    .max(max)
    .regex(/^\P{Cc}*$/u);
export const CHANGE_KINDS = [
  "course_shift",
  "school_transfer",
  "both",
  "year_level_correction",
  "course_completion",
] as const;
export function parseAcademicChange(raw: unknown) {
  const parsed = z
    .object({
      expectedVersion: z.number().int().min(0),
      kind: z.enum(CHANGE_KINDS),
      ...placementReferences,
      yearLevel: text(1, 60),
      effectiveOn: z.iso
        .date()
        .refine(
          (d) => d >= "1900-01-01" && d <= today(),
          "Use a date from 1900 through today.",
        ),
      reason: text(5, 500),
      reference: text(3, 300),
      remarks: text(0, 1000),
    })
    .strict()
    .refine(hasPlacementReferences, "Provide school and course details.")
    .safeParse(raw);
  if (!parsed.success)
    throw new AuthError(
      422,
      "VALIDATION_FAILED",
      "Provide a valid placement, effective date, reason, reference and remarks.",
      validationDetails(parsed.error),
    );
  return parsed.data;
}
export function validatePlacementChange(
  before: Placement,
  input: ReturnType<typeof parseAcademicChange>,
) {
  const school = before.schoolId !== input.schoolId,
    course = before.courseId !== input.courseId,
    level = before.yearLevel !== input.yearLevel;
  if(before.coursePending && input.kind !== "course_completion") throw new AuthError(409,"COURSE_COMPLETION_REQUIRED","Complete the unknown course from supporting evidence before recording other placement changes.");
  const valid =
    input.kind === "course_completion"
      ? Boolean(before.coursePending && !before.courseId && input.courseId && !school && !level)
      : input.kind === "course_shift"
      ? course && !school && !level
      : input.kind === "school_transfer"
        ? school && !course && !level
        : input.kind === "both"
          ? school && course && !level
          : level && !school && !course;
  if (!valid)
    throw new AuthError(
      409,
      "INVALID_ACADEMIC_CHANGE",
      "Change only the fields allowed by the selected type. Record year-level corrections separately.",
    );
}
