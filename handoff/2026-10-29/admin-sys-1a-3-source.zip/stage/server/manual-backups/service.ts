import {randomUUID} from 'node:crypto';
import type {RowDataPacket} from 'mysql2/promise';
import {z} from 'zod';
import {AuthError} from '../auth/service.js';
import {digest} from '../auth/crypto.js';
import {requestSecurity} from '../auth/request-context.js';
import type {AuthorizationService} from '../authorization/service.js';
import {decodeStoredJson} from '../stored-json.js';
import type {BackupTransport,WorkerRequest} from './model.js';
const input=z.object({reason:z.string().trim().min(5).max(500).regex(/^\P{Cc}*$/u),confirmed:z.literal(true),sourceVersion:z.string().regex(/^[a-f0-9]{64}$/)}).strict();
const id=z.uuid();
export class ManualBackups{
 constructor(private authorization:AuthorizationService,private transport:BackupTransport){}
 private principal(){const p=requestSecurity()?.principal;if(!p)throw new AuthError(401,'SESSION_EXPIRED','Sign in again to manage backups.');return {userId:p.userId,tokenHash:p.tokenHash,accountVersion:p.accountVersion};}
 private async call(request:WorkerRequest){try{return await this.transport(request);}catch(e){const code=e&&typeof e==='object'&&'code'in e?String(e.code):'';if(code==='SESSION_EXPIRED')throw new AuthError(401,code,'Your session expired. Sign in again.');if(code==='PERMISSION_DENIED')throw new AuthError(403,code,'System Administrator access is required.');if(['SOURCE_CHANGED','REQUEST_INVALID','IDEMPOTENCY_CONFLICT','HISTORY_CAPACITY'].includes(code))throw new AuthError(409,'BACKUP_'+code,'Backup was not started: '+({SOURCE_CHANGED:'the source changed. Refresh and review it.',REQUEST_INVALID:'the request was rejected.',IDEMPOTENCY_CONFLICT:'use the exact original request.',HISTORY_CAPACITY:'backup history requires operator review.'} as Record<string,string>)[code]);throw new AuthError(503,'BACKUP_WORKER_UNAVAILABLE','Backup service is unavailable. Keep any unconfirmed request and retry it exactly.');}}
 read(actor:string,op:'availability'|'list'|'detail',query:{offset?:unknown;id?:unknown}={}){return this.authorization.readSnapshot(actor,'users.manage',async(_db,access)=>{if(!access.roles.some(r=>r.code==='system_admin'))throw new AuthError(403,'PERMISSION_DENIED','System Administrator access is required.');const offset=z.coerce.number().int().min(0).max(500).safeParse(query.offset??0);if(!offset.success||query.id!==undefined&&!id.safeParse(query.id).success)throw new AuthError(422,'VALIDATION_FAILED','Choose a valid backup page.');return this.call({op,principal:this.principal(),...(op==='list'?{offset:offset.data}:{}),...(op==='detail'?{id:String(query.id)}:{})});});}
 async create(actor:string,keyValue:unknown,raw:unknown,requestId:string){const parsed=input.safeParse(raw),key=id.safeParse(keyValue);if(!parsed.success||!key.success)throw new AuthError(422,'VALIDATION_FAILED','Provide a reason and confirm the backup.');const body=parsed.data,hash=digest(JSON.stringify({kind:'manual-backup/v1',actor,body}));
 // First lookup/authorize in the guarded transaction. Never dispatch before commit.
 const receipt=await this.authorization.withPermission(actor,'users.manage',async(db,access)=>{if(!access.roles.some(r=>r.code==='system_admin'))throw new AuthError(403,'PERMISSION_DENIED','System Administrator access is required.');const [[prior]]=await db.execute<RowDataPacket[]>('SELECT payload_hash,result FROM configuration_commands WHERE actor_id=? AND request_id=?',[actor,key.data]);if(prior){const result=decodeStoredJson<{kind:string;id:string;reason:string}>(prior.result);if(prior.payload_hash!==hash||result.kind!=='manual-backup/v1')throw new AuthError(409,'IDEMPOTENCY_CONFLICT','Use the exact original backup request.');return result;}
 const [[count]]=await db.query<RowDataPacket[]>("SELECT COUNT(*) n FROM configuration_commands WHERE JSON_UNQUOTE(JSON_EXTRACT(result,'$.kind'))='manual-backup/v1'");if(Number(count.n)>=500)throw new AuthError(409,'BACKUP_HISTORY_CAPACITY','Backup history requires operator review before another job.');
 const result={kind:'manual-backup/v1',id:randomUUID(),reason:body.reason,sourceVersion:body.sourceVersion};
 await db.execute("INSERT INTO audit_logs(id,event_type,entity_type,entity_id,action,actor_id,actor_kind,occurred_at,request_id,reason,details) VALUES(?,'backup.requested','backup',?,'create',?,'user',UTC_TIMESTAMP(6),?,?,?)",[randomUUID(),result.id,actor,requestId,body.reason,JSON.stringify({jobId:result.id,kind:result.kind,offHostRecoveryVerified:false})]);
 await db.execute('INSERT INTO configuration_commands(actor_id,request_id,payload_hash,result,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP(6))',[actor,key.data,hash,JSON.stringify(result)]);return result;});
 // A transport error after admission is uncertain: the same ledger receipt/body/key is recovered.
 return this.call({op:'admit',principal:this.principal(),admission:{id:receipt.id,key:key.data,hash}});
 }
}
