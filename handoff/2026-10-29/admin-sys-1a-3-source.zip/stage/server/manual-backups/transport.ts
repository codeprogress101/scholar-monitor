import tls from 'node:tls';
import {readFile,stat} from 'node:fs/promises';
import type {BackupTransport,WorkerRequest} from './model.js';
/** Dedicated client certificate is only an IPC capability, never a SQL or archive key. */
export function localTransport():BackupTransport{return async request=>{
 const file='C:/ProgramData/LDSS-IPUAT-BackupWorker/bin/api-client.json';if((await stat(file)).size>16384)throw new Error('IPC configuration bound');
 const config=JSON.parse(await readFile(file,'utf8')) as {version:number;port:number;clientPfx:string;passphrase:string;ca:string;serverFingerprint:string};
 if(config.version!==1||config.port!==3041||config.clientPfx.replaceAll('\\','/').toLowerCase()!=='c:/programdata/ldss-ipuat-backupworker/bin/ipc-client.pfx'||!/^[a-f0-9]{64}$/.test(config.serverFingerprint))throw new Error('Unexpected IPC binding');
 if((await stat(config.clientPfx)).size>65536)throw new Error('IPC certificate bound');const pfx=await readFile(config.clientPfx);
 return requestTls(config,pfx,request);};}
export function requestTls(config:{port:number;passphrase:string;ca:string;serverFingerprint:string},pfx:Buffer,request:WorkerRequest):Promise<unknown>{
 return new Promise((resolve,reject)=>{const data=Buffer.from(JSON.stringify(request));if(data.length>8192){reject(new Error('IPC request bound'));return;}
 const socket=tls.connect({host:'127.0.0.1',port:config.port,servername:'ldss-ipuat-backup',pfx,passphrase:config.passphrase,ca:config.ca,minVersion:'TLSv1.2',rejectUnauthorized:true});let buffer=Buffer.alloc(0),done=false;
 const fail=()=>{if(done)return;done=true;socket.destroy();reject(new Error('Backup IPC unavailable'));};socket.setTimeout(5000,fail);socket.on('error',fail);
 socket.on('secureConnect',()=>{if(!socket.authorized||socket.getPeerCertificate().fingerprint256?.replaceAll(':','').toLowerCase()!==config.serverFingerprint){fail();return;}const size=Buffer.alloc(4);size.writeUInt32LE(data.length);socket.write(Buffer.concat([size,data]));});
 socket.on('data',part=>{buffer=Buffer.concat([buffer,part]);if(buffer.length>262148){fail();return;}if(buffer.length<4)return;const size=buffer.readUInt32LE(0);if(size<1||size>262144){fail();return;}if(buffer.length===size+4){try{const result=JSON.parse(buffer.subarray(4).toString('utf8'));done=true;socket.destroy();if(result.error){const e=new Error('Backup worker refused request') as Error&{code:string};e.code=String(result.error);reject(e);}else resolve(result.result);}catch{fail();}}});socket.on('end',()=>{if(!done)fail();});
 });}
