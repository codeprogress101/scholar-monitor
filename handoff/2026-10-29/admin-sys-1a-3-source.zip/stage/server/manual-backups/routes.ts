import type {FastifyInstance} from 'fastify';
import type {ManualBackups} from './service.js';
export function registerManualBackups(app:FastifyInstance,service:ManualBackups){
 app.get('/api/v1/admin/backups/availability',{config:{permission:'users.manage'}},r=>service.read(r.authSession!.user.id,'availability'));
 app.get('/api/v1/admin/backups',{config:{permission:'users.manage'}},r=>service.read(r.authSession!.user.id,'list',r.query as {offset?:unknown}));
 app.get<{Params:{id:string}}>('/api/v1/admin/backups/:id',{config:{permission:'users.manage'}},r=>service.read(r.authSession!.user.id,'detail',{id:r.params.id}));
 app.post('/api/v1/admin/backups',{bodyLimit:4096,config:{permission:'users.manage'}},r=>service.create(r.authSession!.user.id,r.headers['idempotency-key'],r.body,r.id));
}
