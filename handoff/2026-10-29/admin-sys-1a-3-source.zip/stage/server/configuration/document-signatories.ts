import {officialIds,signingRoles,type SignatoryData,type SignatoryState} from "./document-signatory-model.js";
export {officialIds,signingRoles,type SignatoryData,type SignatoryState} from "./document-signatory-model.js";
import {z} from 'zod';
import type {PoolConnection,RowDataPacket} from 'mysql2/promise';
import {randomUUID} from 'node:crypto';
import {AuthError} from '../auth/service.js';
import {digest} from '../auth/crypto.js';
import type {AuthorizationService} from '../authorization/service.js';
import {parseKey} from './validation.js';
import {decodeStoredJson} from '../stored-json.js';

export const SIGN_PREFIX='FIN_SIGN_';
const plain=(max:number)=>z.string().trim().max(max).refine(s=>Array.from(s).every(c=>{const n=c.codePointAt(0)!;return n>=32&&n!==127&&!(n>=0xd800&&n<=0xdfff)&&n%65536<65534;}),'Use valid single-line printed text.');
const official=z.object({id:z.enum(officialIds),name:plain(80),position:plain(100).min(1)}).strict();
export const signatoryData=z.object({officials:z.array(official).length(8),capacities:z.array(z.object({id:z.enum(signingRoles.map(r=>r.id)),text:plain(120)}).strict()).length(10),authorityReference:plain(240)}).strict().superRefine((d,c)=>{
 if(new Set(d.officials.map(x=>x.id)).size!==8||new Set(d.capacities.map(x=>x.id)).size!==10)c.addIssue({code:'custom',message:'Provide each official and signing section once.'});
 for(const row of d.officials)if(!row.id.startsWith('or-')&&!row.name)c.addIssue({code:'custom',message:'Required DV/Payroll officials need a printed name.'});
});
const normalize=(raw:unknown):SignatoryData=>{const r=signatoryData.safeParse(raw);if(!r.success)throw new AuthError(422,'INVALID_SIGNATORIES',r.error.issues.map(x=>x.message).join(' ').slice(0,500));return {...r.data,officials:[...r.data.officials].sort((a,b)=>a.id.localeCompare(b.id)),capacities:[...r.data.capacities].sort((a,b)=>a.id.localeCompare(b.id))};};
const headCode=SIGN_PREFIX+'HEAD',rowCode=(type:string,id:string)=>SIGN_PREFIX+type+'_'+id.toUpperCase().replaceAll('-','_');
const missing=(data:SignatoryData)=>data.officials.filter(x=>!x.name).map(x=>x.position);
export function initialSignatories(legacy:{name:string;title:string}[]):SignatoryData{return normalize({authorityReference:'SIGN-1 user-provided fictional UAT configuration; not office appointment authority',officials:[
 {id:'accountant',name:'CAROLINE MAISIE J. ROBLES',position:'Municipal Accountant'},{id:'treasurer',name:'RODANTE V. FORBES',position:'Municipal Treasurer'},{id:'mayor',name:'ROSSANO C. VALENCIA',position:'Municipal Mayor'},{id:'coordinator',name:'RANNEL V. FARAON',position:'Scholarship Coordinator'},
 {id:'grantee',name:legacy[0].name,position:legacy[0].title},{id:'disburser',name:legacy[3].name,position:legacy[3].title},{id:'or-administrator',name:'',position:'Municipal Administrator'},{id:'or-budget',name:'',position:'Municipal Budget Officer'}],capacities:signingRoles.map(r=>({id:r.id,text:r.id==='DV_A'?'Head, Accounting Unit / Authorized Representative':r.id==='DV_B'?'Treasurer / Authorized Representative':''}))});}
export async function readDocumentSignatories(db:PoolConnection):Promise<SignatoryState|null>{
 const[rows]=await db.execute<RowDataPacket[]>("SELECT code,version,setting_value,archived_at FROM system_settings WHERE code LIKE 'FIN\\_SIGN\\_%' LIMIT 20");if(!rows.length)return null;
 const head=rows.find(r=>r.code===headCode);if(rows.length!==19||!head||rows.some(r=>r.archived_at||Number(r.version)!==Number(head.version)))throw new AuthError(409,'SIGNATORY_CONFIGURATION_INVALID','Review Document Signatories; preserve the recorded configuration.');
 try{const h=decodeStoredJson<{schema:string;effectiveOn:string;hash:string;authorityReference:string}>(head.setting_value);if(h.schema!=='financial-signatories/v1'||!/^\d{4}-\d{2}-\d{2}$/.test(h.effectiveOn))throw Error();
 const value=(code:string)=>{const r=rows.find(r=>r.code===code);if(!r)throw Error();return decodeStoredJson(r.setting_value);};
 const data=normalize({officials:officialIds.map(id=>value(rowCode('O',id))),capacities:signingRoles.map(r=>value(rowCode('R',r.id))),authorityReference:h.authorityReference});if(digest(JSON.stringify(data))!==h.hash)throw Error();return{version:Number(head.version),effectiveOn:h.effectiveOn,hash:h.hash,data,missing:missing(data)};
 }catch{throw new AuthError(409,'SIGNATORY_CONFIGURATION_INVALID','Review the versioned signatory source before generating a form.');}
}
export function signatoryMapping(state:SignatoryState,document:'DV'|'OR'|'Payroll'){
 return signingRoles.filter(r=>r.document===document).map(r=>{const o=state.data.officials.find(o=>o.id===r.official)!;return{section:r.id,label:r.section,officialId:o.id,name:o.name,title:o.position,capacity:state.data.capacities.find(x=>x.id===r.id)!.text};});
}
export class DocumentSignatoryService{
 constructor(private authorization:AuthorizationService){}
 read(actor:string){return this.authorization.readSnapshot(actor,'configuration.manage',async(db,access)=>{if(!access.roles.some(r=>r.code==='system_admin'))throw new AuthError(403,'PERMISSION_DENIED','System Administrator access is required.');const current=await readDocumentSignatories(db);if(current)return current;const[[legacy]]=await db.execute<RowDataPacket[]>("SELECT setting_value FROM system_settings WHERE code='PAYROLL_SIGNATORIES' AND archived_at IS NULL");if(!legacy)throw new AuthError(409,'SIGNATORIES_REQUIRED','Existing payroll signatories need setup first.');const data=initialSignatories(decodeStoredJson(legacy.setting_value));return{version:0,effectiveOn:null,hash:'',data,missing:missing(data)}as SignatoryState;});}
 write(actor:string,rawKey:unknown,raw:unknown,requestId:string){const key=parseKey(rawKey),parsed=z.object({expectedVersion:z.number().int().nonnegative(),confirmed:z.literal(true),reason:z.string().trim().min(5).max(500),data:z.unknown()}).strict().safeParse(raw);if(!parsed.success)throw new AuthError(422,'VALIDATION_FAILED','Confirm the reviewed configuration, current version and reason.');const input={...parsed.data,data:normalize(parsed.data.data)},hash=digest(JSON.stringify(input));
 return this.authorization.withPermission(actor,'configuration.manage',async(db,access)=>{if(!access.roles.some(r=>r.code==='system_admin'))throw new AuthError(403,'PERMISSION_DENIED','System Administrator access is required.');
 const[[prior]]=await db.execute<RowDataPacket[]>('SELECT payload_hash,result FROM configuration_commands WHERE actor_id=? AND request_id=?',[actor,key]);if(prior){if(prior.payload_hash!==hash)throw new AuthError(409,'IDEMPOTENCY_CONFLICT','Retry only the exact saved signatory change.');return decodeStoredJson<SignatoryState>(prior.result);}
 const before=await readDocumentSignatories(db);if((before?.version??0)!==input.expectedVersion)throw new AuthError(409,'VERSION_CONFLICT','Signatories changed. Refresh and review the current version.');const version=input.expectedVersion+1,effectiveOn=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()),data=input.data,sourceHash=digest(JSON.stringify(data));
 const values=[{code:headCode,value:{schema:'financial-signatories/v1',effectiveOn,hash:sourceHash,authorityReference:data.authorityReference}},...data.officials.map(r=>({code:rowCode('O',r.id),value:r})),...data.capacities.map(r=>({code:rowCode('R',r.id),value:r}))];
 for(const row of values){const value=JSON.stringify(row.value);if(value.length>1000||Buffer.byteLength(value)>4000)throw new AuthError(422,'INVALID_SIGNATORIES','One signatory entry exceeds existing storage bounds.');if(before)await db.execute('UPDATE system_settings SET setting_value=?,version=?,updated_at=UTC_TIMESTAMP(6) WHERE code=?',[value,version,row.code]);else await db.execute("INSERT INTO system_settings(id,code,name,version,value_type,setting_value,created_at,updated_at) VALUES(?,?,?,?,'text',?,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))",[randomUUID(),row.code,'Financial document signatory '+row.code,version,value]);}
 const after=await readDocumentSignatories(db);await db.execute("INSERT INTO audit_logs(id,event_type,entity_type,entity_id,action,actor_id,actor_kind,occurred_at,request_id,reason,details) VALUES(?,'configuration.changed','document_signatories',?,'signatories.update',?,'user',UTC_TIMESTAMP(6),?,?,?)",[randomUUID(),headCode,actor,requestId,input.reason,JSON.stringify({before,after,immediate:true,paymentChanged:false})]);await db.execute('INSERT INTO configuration_commands(actor_id,request_id,payload_hash,result,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP(6))',[actor,key,hash,JSON.stringify(after)]);return after!;
 });}
}
