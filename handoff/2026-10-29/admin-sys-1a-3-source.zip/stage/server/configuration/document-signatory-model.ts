export const officialIds=['accountant','treasurer','mayor','coordinator','grantee','disburser','or-administrator','or-budget'] as const;
export const signingRoles=[
 {id:'DV_A',document:'DV',section:'A. Certified',official:'accountant'},
 {id:'DV_B',document:'DV',section:'B. Certified',official:'treasurer'},
 {id:'DV_C',document:'DV',section:'C. Approved for Payment',official:'mayor'},
 {id:'OR_A',document:'OR',section:'A. Certified — lawful charges / supporting documents',official:'or-administrator'},
 {id:'OR_B',document:'OR',section:'B. Certified — appropriation available',official:'or-budget'},
 {id:'PAY_1',document:'Payroll',section:'Grantee certification',official:'grantee'},
 {id:'PAY_2',document:'Payroll',section:'Approval for payment',official:'mayor'},
 {id:'PAY_3',document:'Payroll',section:'Treasurer certification',official:'treasurer'},
 {id:'PAY_4',document:'Payroll',section:'Disbursing officer certification',official:'disburser'},
 {id:'PAY_5',document:'Payroll',section:'Scholarship Coordinator',official:'coordinator'},
] as const;
export type SignatoryData={officials:{id:typeof officialIds[number];name:string;position:string}[];capacities:{id:typeof signingRoles[number]['id'];text:string}[];authorityReference:string};
export type SignatoryState={version:number;effectiveOn:string|null;hash:string;data:SignatoryData;missing:string[]};
