import { AsyncLocalStorage } from "node:async_hooks";
import type { Access } from "../authorization/policy.js";

export type SessionPrincipal = Readonly<{
  userId: string;
  tokenHash: string;
  accountVersion: number;
  idleMinutes: number;
}>;
type RequestSecurity = { principal?: SessionPrincipal; passiveAccess?: Access };
const requests = new AsyncLocalStorage<RequestSecurity>();
const construction = new AsyncLocalStorage<boolean>();

/** Capture a fail-closed mode in every authorization service built by the app. */
export function constructHttpServices<T>(factory: () => T): T {
  return construction.run(true, factory);
}

export function isHttpServiceConstruction() {
  return construction.getStore() === true;
}

/** One server-owned scope per HTTP request. Missing admission fails closed. */
export function beginHttpRequest(done: () => void) {
  requests.run({principal: undefined, passiveAccess: undefined}, done);
}

/** Called only after authoritative session validation, never from request bodies. */
export function admitSession(principal: SessionPrincipal, passiveAccess?: Access) {
  const scope = requests.getStore();
  if (scope) {
    scope.principal = Object.freeze(principal);
    scope.passiveAccess = passiveAccess;
  }
}

export function requestSecurity() {
  return requests.getStore();
}
