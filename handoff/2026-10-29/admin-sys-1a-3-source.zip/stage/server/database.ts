import { schemaReady } from "./schema-readiness.js";
import mysql from "mysql2/promise";
import type { AppConfig } from "./config.js";

export type DatabaseStatus = "connected" | "unavailable" | "not_configured";
export type Database = {
  pool?: mysql.Pool;
  passiveAuthPool?: mysql.Pool;
  check: () => Promise<DatabaseStatus>;
  close: () => Promise<void>;
};

export function createDatabase(config: AppConfig): Database {
  if (!config.DB_USER)
    return {
      check: async () => "not_configured",
      close: async () => {},
    };
  const options = {jsonStrings: true,
    host: config.DB_HOST,
    port: config.DB_PORT,
    database: config.DB_NAME,
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    connectionLimit: 4,
    waitForConnections: true,
    queueLimit: 100,
    connectTimeout: 3000,
    multipleStatements: false,
    timezone: "Z",
    charset: "utf8mb4",
  };
  const pool = mysql.createPool(options);
  // Passive authentication must not queue behind guarded business requests.
  const passiveAuthPool = mysql.createPool({...options, connectionLimit: 2, queueLimit: 16});
  return {
    pool,
    passiveAuthPool,
    async check() {
      try {
        const [rows] = await pool.query<mysql.RowDataPacket[]>({
          sql: "SELECT version,checksum FROM schema_migrations",
          timeout: 3000,
        });
        const [settings] = await pool.query<(mysql.RowDataPacket & {code: string; setting_value: string})[]>({sql: "SELECT code,setting_value FROM system_settings WHERE code='PAYROLL_SIGNATORIES' AND archived_at IS NULL", timeout: 3000});
        return schemaReady(rows as (mysql.RowDataPacket & {version: string; checksum: string})[], settings) ? "connected" : "unavailable";
      } catch {
        return "unavailable";
      }
    },
    close: async () => { await Promise.all([pool.end(), passiveAuthPool.end()]); },
  };
}
