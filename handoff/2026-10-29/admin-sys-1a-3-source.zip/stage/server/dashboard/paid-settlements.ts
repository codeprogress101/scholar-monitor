import type {PoolConnection,RowDataPacket} from 'mysql2/promise';
import {AuthError} from '../auth/service.js';
import type {PayoutCycle} from '../payouts/model.js';
import {effectiveOutcomeSql,effectivePaymentJoinsSql} from '../payments/effective-payment-sql.js';
import {reportCents} from '../payments/report-model.js';

/** Effective payments in one semester, using the same correction precedence and
 * scholar/semester entitlement relation as Individual Settlement reports.
 * This is a read projection, never an eligibility or payment authorization. */
export async function paidSettlements(db:PoolConnection,cycle:PayoutCycle,offset=0,limit=25){
 const [rows]=await db.execute<RowDataPacket[]>(`SELECT p.id,p.source_kind,p.individual_transaction_id,p.scholarship_id,
 e.id entitlement_id,e.scholar_id,e.amount_centavos,t.entitlement_id transaction_entitlement,
 IF(c.id IS NULL,p.amount,JSON_UNQUOTE(JSON_EXTRACT(c.snapshot,'$.after.amount'))) effective_amount,
 IF(c.id IS NULL,DATE_FORMAT(p.effective_on,'%Y-%m-%d'),JSON_UNQUOTE(JSON_EXTRACT(c.snapshot,'$.after.effectiveOn'))) paid_on,
 i.human_id,CONCAT_WS(' ',s.last_name,s.first_name,NULLIF(s.middle_name,''),NULLIF(s.suffix,'')) name,
 COALESCE(p.batch_id,t.source_batch_id) batch_id,b.code batch_code,b.cycle_id,
 t.internal_reference,t.source_kind individual_source_kind,
 EXISTS(SELECT 1 FROM payment_corrections pending WHERE pending.payment_id=p.id AND pending.state='pending' AND NOT EXISTS(SELECT 1 FROM payment_corrections n WHERE n.id=pending.id AND n.version>pending.version)) pending_correction
 FROM payment_records p JOIN payout_cycles pc ON pc.id=p.cycle_id JOIN semesters sem ON sem.id=pc.semester_id
 JOIN scholarship_records annual ON annual.id=p.scholarship_id JOIN scholars s ON s.id=annual.scholar_id
 JOIN scholar_identifiers i ON i.scholar_id=s.id
 LEFT JOIN semester_entitlements e ON e.scholar_id=annual.scholar_id AND e.semester_id=sem.id
 LEFT JOIN individual_payment_transactions t ON t.id=p.individual_transaction_id
 LEFT JOIN ovr_batches b ON b.id=COALESCE(p.batch_id,t.source_batch_id)
 ${effectivePaymentJoinsSql}
 WHERE sem.academic_year_id=? AND sem.id=? AND ${effectiveOutcomeSql}='paid'
 ORDER BY paid_on DESC,p.id LIMIT 5001`,[cycle.academicYearId,cycle.semesterId]);
 if(rows.length>5000)throw new AuthError(422,'REPORT_SCOPE_TOO_LARGE','Unified Paid reporting supports at most 5,000 effective Paid transactions per semester. No partial total is shown.');
 const seen=new Set<string>(),people=new Set<string>();let payroll=0,individual=0,centavos=0,pendingCorrections=0;
 const items=rows.map(r=>{
  const amount=reportCents(r.effective_amount),isIndividual=r.source_kind==='individual';
  if(!r.entitlement_id||!r.batch_id||!['payroll','individual'].includes(r.source_kind)||seen.has(r.entitlement_id)||amount!==Number(r.amount_centavos)||(isIndividual&&r.transaction_entitlement!==r.entitlement_id))throw new AuthError(409,'PAID_SETTLEMENT_REVIEW_REQUIRED','Paid evidence has a missing, conflicting or mismatched stipend obligation. Review source payment history; a merged total is unavailable.');
  seen.add(r.entitlement_id);people.add(r.scholar_id);centavos+=amount;if(!Number.isSafeInteger(centavos))throw new AuthError(409,'REPORT_EVIDENCE_INVALID','The Paid amount exceeds the supported exact range.');
  if(isIndividual)individual++;else payroll++;pendingCorrections+=Number(Boolean(r.pending_correction));
  return {paymentId:String(r.id),entitlementId:String(r.entitlement_id),name:String(r.name),humanId:String(r.human_id),amountCentavos:amount,paidOn:String(r.paid_on),channel:isIndividual?'individual' as const:'payroll' as const,reference:isIndividual?String(r.internal_reference):String(r.batch_code),sourceDetail:isIndividual?String(r.individual_source_kind):'payroll',href:isIndividual?'#individual-payments?'+new URLSearchParams({view:'cheques',transaction:String(r.individual_transaction_id)}):'#payouts?'+new URLSearchParams({cycle:String(r.cycle_id),batch:String(r.batch_id),view:'recording'})};
 });
 return {academicYearId:cycle.academicYearId,semesterId:cycle.semesterId,yearCode:cycle.yearCode,semesterCode:cycle.semesterCode,totalPaid:seen.size,paidScholars:people.size,paidTransactions:rows.length,paidCentavos:centavos,payroll,individual,pendingCorrections,items:items.slice(offset,offset+limit),offset,limit,total:items.length,scope:'Current effective Paid stipend obligations in this academic year and semester, across payout cycles. Applied/approved corrections replace outcomes; original records remain unchanged. Unclaimed and Pending are not Paid. Conflicting Paid obligations stop the total.'};
}
export type PaidSettlements=Awaited<ReturnType<typeof paidSettlements>>;
