import type{PoolConnection,RowDataPacket}from'mysql2/promise';
import{AuthError}from'../auth/service.js';
import type{PayoutCycle}from'../payouts/model.js';
import{effectiveOutcomeSql,effectiveUnpaidReasonSql,effectivePaymentJoinsSql}from'../payments/effective-payment-sql.js';
import{paidSettlements,type PaidSettlements}from'./paid-settlements.js';
export const paymentViews=['all','paid','pending','unclaimed','needsReview','sourceUnclaimed','payrollPaid','individualPaid'] as const;
export type PaymentView=typeof paymentViews[number];
type Source={kind:'payroll'|'individual';reference:string;href:string;status:string;recordedPayment:boolean};
export type Obligation={entitlementId:string;name:string;humanId:string;amountCentavos:number;status:'paid'|'pending'|'unclaimed'|'needsReview';paidOn:string|null;sources:Source[];href:string;settledUnclaimed:boolean;paidChannel?:'payroll'|'individual'};
const refuse=(message:string):never=>{throw new AuthError(409,'PAYMENT_OVERVIEW_REVIEW_REQUIRED',message);};
/** Reporting classification only: no source eligibility, authorization or writer.
 * Prepared individual attempts use the existing Pending Payment queue scope.
 * A validated Paid settlement wins over its retained unpaid payroll source.
 * Multiple unpaid payroll attempts require review instead of guessing an owner. */
export function summarizeObligations(ordinary:RowDataPacket[],individual:RowDataPacket[],paid:PaidSettlements['items']){
 const values=new Map<string,Obligation>();const original={total:ordinary.length,paid:0,pending:0,unclaimed:0,needsReview:0,settledUnclaimed:0};
 for(const r of[...ordinary,...individual]){const id=String(r.entitlement_id),amount=Number(r.amount_centavos);if(!r.entitlement_id||!Number.isSafeInteger(amount)||amount<0)refuse('A stipend obligation or approved amount is unavailable. Preserve its source evidence.');
  let item=values.get(id);if(!item){item={entitlementId:id,name:String(r.name),humanId:String(r.human_id),amountCentavos:amount,status:'pending',paidOn:null,sources:[],href:'',settledUnclaimed:false};values.set(id,item);}else if(item.amountCentavos!==amount||item.humanId!==String(r.human_id))refuse('Stipend identity or amount disagrees across sources.');
  const kind=r.kind==='individual'?'individual' as const:'payroll' as const,href=kind==='individual'?'#individual-payments?'+new URLSearchParams({view:'cheques',transaction:String(r.transaction_id)}):'#payouts?'+new URLSearchParams({cycle:String(r.cycle_id),batch:String(r.batch_id),view:'recording'});
  item.sources.push({kind,reference:String(r.reference),href,status:String(r.status),recordedPayment:Boolean(r.payment_id)});if(kind==='payroll'){if(!['paid','pending','unclaimed','needsReview'].includes(r.status))refuse('A payroll outcome is unsupported.');original[r.status as 'paid'|'pending'|'unclaimed'|'needsReview']++;}
 }
 if(values.size>5000)throw new AuthError(422,'REPORT_SCOPE_TOO_LARGE','Payment Overview supports up to 5,000 stipend obligations per semester. No partial counts are shown.');
 const paidById=new Map(paid.map(p=>[p.entitlementId,p]));for(const p of paid)if(!values.has(p.entitlementId))refuse('A Paid obligation is missing its finalized payroll or individual source.');
 const counts={paid:0,pending:0,unclaimed:0,needsReview:0},pendingBySource={payroll:0,individual:0};
 for(const item of values.values()){const payment=paidById.get(item.entitlementId),payroll=item.sources.filter(s=>s.kind==='payroll');
  if(!payment&&item.sources.some(s=>s.status==='paid'))refuse('Paid source records disagree with the effective Paid projection.');
  if(payment){if(payment.amountCentavos!==item.amountCentavos)refuse('Paid and approved amounts disagree.');item.status='paid';item.paidChannel=payment.channel;item.paidOn=payment.paidOn;item.href=payment.href;item.settledUnclaimed=payroll.some(s=>s.status==='unclaimed');if(item.settledUnclaimed)original.settledUnclaimed++;}
  else{item.status=item.sources.some(s=>s.kind==='individual'&&s.recordedPayment)||payroll.some(s=>s.status==='needsReview')||payroll.length>1?'needsReview':payroll.some(s=>s.status==='unclaimed')?'unclaimed':'pending';item.href=item.sources.find(s=>s.kind==='individual')?.href??item.sources[0].href;if(item.status==='pending')pendingBySource[payroll.length?'payroll':'individual']++;}
  counts[item.status]++;
 }
 if(counts.paid!==paid.length)refuse('Paid obligation totals require reconciliation.');
 return {items:[...values.values()].sort((a,b)=>a.humanId.localeCompare(b.humanId)||a.entitlementId.localeCompare(b.entitlementId)),counts,total:values.size,original,pendingBySource};
}
export async function paymentOverview(db:PoolConnection,cycle:PayoutCycle,view:PaymentView='all',offset=0,limit=25){
 const paid=await paidSettlements(db,cycle,0,5000);
 const [frozen]=await db.execute<RowDataPacket[]>(`SELECT b.id,f.entry_count,EXISTS(SELECT 1 FROM ovr_amendments a WHERE a.batch_id=b.id AND a.state='approved') amended FROM ovr_batches b JOIN ovr_finalizations f ON f.batch_id=b.id JOIN payout_cycles c ON c.id=b.cycle_id JOIN semesters s ON s.id=c.semester_id WHERE s.academic_year_id=? AND s.id=? ORDER BY b.id LIMIT 51`,[cycle.academicYearId,cycle.semesterId]);
 if(frozen.length>50)throw new AuthError(422,'REPORT_SCOPE_TOO_LARGE','Payment Overview supports up to 50 finalized payrolls per semester.');
 if(frozen.some(r=>r.amended))refuse('An amended historical payroll requires its existing reviewed tools.');
 const [ordinary]=await db.execute<RowDataPacket[]>(`SELECT e.id entitlement_id,e.amount_centavos,i.human_id,CONCAT_WS(' ',s.last_name,s.first_name,NULLIF(s.middle_name,''),NULLIF(s.suffix,'')) name,
 'payroll' kind,b.id batch_id,b.cycle_id,b.code reference,p.id payment_id,
 CASE WHEN p.id IS NULL THEN 'pending' WHEN ${effectiveOutcomeSql}='paid' THEN 'paid' WHEN ${effectiveUnpaidReasonSql}='did_not_claim' THEN 'unclaimed' ELSE 'needsReview' END status
 FROM (SELECT batch_id,scholarship_id,entitlement_id FROM payroll_allocations UNION SELECT a.batch_id,a.scholarship_id,q.entitlement_id FROM payroll_reprocessing_attempts a JOIN payroll_reprocessing q ON q.id=a.reprocessing_id) member
 JOIN semester_entitlements e ON e.id=member.entitlement_id JOIN semesters sem ON sem.id=e.semester_id
 JOIN ovr_batches b ON b.id=member.batch_id JOIN ovr_finalizations f ON f.batch_id=b.id
 JOIN scholarship_records annual ON annual.id=member.scholarship_id AND annual.scholar_id=e.scholar_id
 JOIN scholars s ON s.id=e.scholar_id JOIN scholar_identifiers i ON i.scholar_id=s.id
 LEFT JOIN payment_records p ON p.batch_id=b.id AND p.scholarship_id=annual.id ${effectivePaymentJoinsSql}
 WHERE sem.academic_year_id=? AND sem.id=? ORDER BY b.code,e.id LIMIT 5001`,[cycle.academicYearId,cycle.semesterId]);
 const [individual]=await db.execute<RowDataPacket[]>(`SELECT e.id entitlement_id,e.amount_centavos,i.human_id,CONCAT_WS(' ',s.last_name,s.first_name,NULLIF(s.middle_name,''),NULLIF(s.suffix,'')) name,
 'individual' kind,t.id transaction_id,t.internal_reference reference,p.id payment_id,
 CASE WHEN ${effectiveOutcomeSql}='paid' THEN 'paid' WHEN p.id IS NOT NULL THEN 'needsReview' ELSE 'pending' END status
 FROM individual_payment_transactions t JOIN semester_entitlements e ON e.id=t.entitlement_id JOIN semesters sem ON sem.id=e.semester_id
 JOIN scholars s ON s.id=e.scholar_id JOIN scholar_identifiers i ON i.scholar_id=s.id
 JOIN individual_payment_events ev ON ev.transaction_id=t.id AND NOT EXISTS(SELECT 1 FROM individual_payment_events n WHERE n.transaction_id=ev.transaction_id AND n.revision>ev.revision)
 LEFT JOIN payment_records p ON p.individual_transaction_id=t.id ${effectivePaymentJoinsSql}
 WHERE sem.academic_year_id=? AND sem.id=? AND (p.id IS NOT NULL OR ev.action IN ('prepared','forwarded','cancel_rejected','cancel_requested'))
 ORDER BY t.recorded_at,t.id LIMIT 5001`,[cycle.academicYearId,cycle.semesterId]);
 if(ordinary.length>5000||individual.length>5000||new Set(ordinary.map(r=>r.batch_id)).size>50)throw new AuthError(422,'REPORT_SCOPE_TOO_LARGE','Payment Overview exceeds its bounded source scope. No partial totals are shown.');
 const batchCounts=new Map<string,number>();for(const r of ordinary)batchCounts.set(String(r.batch_id),(batchCounts.get(String(r.batch_id))??0)+1);
 if(frozen.some(r=>Number(r.entry_count)!==(batchCounts.get(String(r.id))??0))||[...batchCounts.keys()].some(id=>!frozen.some(r=>String(r.id)===id)))refuse('Frozen payroll membership and allocated obligation counts disagree.');
 const current=summarizeObligations(ordinary,individual,paid.items),selected=current.items.filter(r=>view==='all'||(view==='payrollPaid'?r.status==='paid'&&r.paidChannel==='payroll':view==='individualPaid'?r.status==='paid'&&r.paidChannel==='individual':view==='sourceUnclaimed'?(r.settledUnclaimed||r.status==='unclaimed'):r.status===view));
 return {...paid,items:paid.items.slice(offset,offset+limit),offset,limit,total:paid.total,current:{...current,items:selected.slice(offset,offset+limit),matching:selected.length,view,offset,limit},scope:'Unique stipend obligations from finalized payroll allocations and prepared or recorded individual transactions in the selected semester. Current effective Paid supersedes retained unpaid source outcomes. This is reporting, not eligibility or payment authority.'};
}
export type PaymentOverview=Awaited<ReturnType<typeof paymentOverview>>;
