import type { PoolConnection, RowDataPacket } from "mysql2/promise";
import { ROLE_CODES, isPermission, type Access, type Role, type Permission } from "./policy.js";

/** Caller owns the account/session lock or a single consistent READ ONLY snapshot. */
export async function accessRows(db: PoolConnection, id: string, version: number): Promise<Access> {
  const [roles] = await db.execute<(RowDataPacket & Role)[]>(
    "SELECT r.code,r.label,r.description FROM roles r JOIN user_roles ur ON ur.role_code=r.code WHERE ur.user_id=? AND ur.revoked_at IS NULL ORDER BY r.code",
    [id],
  );
  const [permissions] = await db.execute<(RowDataPacket & Permission)[]>(
    "SELECT DISTINCT p.code,p.label,p.category FROM permissions p JOIN role_permissions rp ON rp.permission_code=p.code JOIN user_roles ur ON ur.role_code=rp.role_code WHERE ur.user_id=? AND ur.revoked_at IS NULL ORDER BY p.category,p.code",
    [id],
  );
  return {
    userId: id,
    version,
    roles: roles.filter(role => ROLE_CODES.includes(role.code)),
    permissions: permissions.filter(permission => isPermission(permission.code)),
  };
}
