import fs from 'node:fs/promises';import path from 'node:path';import mysql from 'mysql2/promise';import type{FastifyInstance}from'fastify';import assert from'node:assert/strict';
import {constructHttpServices}from'../auth/request-context.js';import{AccountAdministration}from'./service.js';import{PrivateHandoff}from'./handoff.js';
export type AccountCapability={database:string;host:string;port:number;user:string;password:string;directory:string;keyFile:string;origin:string;operatorSid:string};
export async function registerAccountAdministration(app:FastifyInstance,cap:AccountCapability,expectedDatabase:string){
 assert.match(expectedDatabase,/^ldss_restore_\d+_[a-f0-9]{8}$/);assert.equal(cap.database,expectedDatabase);assert.equal(cap.host,'127.0.0.1');assert.equal(cap.port,3306);assert.match(cap.user,/^ldss_acct_[a-f0-9]{12}$/);assert.ok(['http://127.0.0.1:5181','http://127.0.0.1:5182'].includes(cap.origin));
 const dir=await fs.realpath(cap.directory),cwd=await fs.realpath(process.cwd());assert.ok(!dir.toLowerCase().startsWith(cwd.toLowerCase()+path.sep),'Handoff must be outside served release');const handoff=new PrivateHandoff(dir,await fs.readFile(cap.keyFile),cap.database);
 const pool=mysql.createPool({host:cap.host,port:cap.port,user:cap.user,password:cap.password,database:cap.database,timezone:'Z',jsonStrings:true,multipleStatements:false,connectionLimit:2,queueLimit:16,waitForConnections:true,connectTimeout:3000});
 try{const[[identity]]=await pool.query<mysql.RowDataPacket[]>('SELECT DATABASE() database_name,CURRENT_USER() account_name,@@hostname host_name');assert.equal(identity.database_name,expectedDatabase);assert.equal(identity.account_name,cap.user+'@localhost');assert.equal(identity.host_name,'DESKTOP-BPLJKRP');await handoff.sweep();}catch(e){await pool.end();throw e;}
 const service=constructHttpServices(()=>new AccountAdministration(pool,handoff));
 app.get('/api/v1/admin/accounts',{config:{permission:'users.manage'}},r=>service.list(r.authSession!.user.id,r.query));
 app.get<{Params:{id:string}}>('/api/v1/admin/accounts/:id/activity',{config:{permission:'users.manage'}},r=>service.activity(r.authSession!.user.id,r.params.id));
 app.post('/api/v1/admin/accounts/commands',{bodyLimit:8192,config:{permission:'users.manage'}},r=>service.command(r.authSession!.user.id,r.headers['idempotency-key'],r.body,r.id));
 const timer=setInterval(()=>void handoff.sweep().catch(()=>{/* Failed storage remains unavailable; never expose secrets. */}),30000);timer.unref();app.addHook('onClose',async()=>{clearInterval(timer);await pool.end();});
}
