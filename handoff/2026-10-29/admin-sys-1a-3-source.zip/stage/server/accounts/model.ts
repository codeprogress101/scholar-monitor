export type AccountRole='staff'|'coordinator'|'system_admin';
export type AccountStatus='active'|'disabled'|'pending';
export type AccountView={id:string;fullName:string;email:string;roles:AccountRole[];status:AccountStatus;version:number;lastLogin:string|null};
export type AccountList={items:AccountView[];total:number;offset:number;limit:number};
export type AccountResult={kind:'account-admin/v1';account:AccountView;handoff?:{reference:string;expiresAt:string}};
export type AccountAction='create'|'edit'|'role'|'disable'|'enable'|'reset';
export type AccountActivity={at:string;event:string;action:string;actor:string;reason:string|null};
