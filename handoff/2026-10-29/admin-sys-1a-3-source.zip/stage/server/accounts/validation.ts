import {z} from 'zod';
import {AuthError,normalizeEmail} from '../auth/service.js';
const role=z.enum(['staff','coordinator','system_admin']);
const name=z.string().trim().min(2).max(160).refine(s=>Array.from(s).every(c=>c.codePointAt(0)!>=32&&c.codePointAt(0)!==127));
const email=z.string().trim().max(254).regex(/^[\x20-\x7e]+$/).email().transform(normalizeEmail);
const common={expectedVersion:z.number().int().nonnegative(),confirmed:z.literal(true),reason:z.string().trim().min(5).max(500)};
const target={...common,targetId:z.uuid(),expectedVersion:z.number().int().positive()};
const command=z.discriminatedUnion('action',[
 z.object({...common,action:z.literal('create'),expectedVersion:z.literal(0),fullName:name,email,role,setupMethod:z.literal('private_operator')}).strict(),
 z.object({...target,action:z.literal('edit'),fullName:name,email}).strict(),
 z.object({...target,action:z.literal('role'),role}).strict(),
 z.object({...target,action:z.literal('enable'),role}).strict(),
 z.object({...target,action:z.literal('disable')}).strict(),
 z.object({...target,action:z.literal('reset')}).strict(),
]);
export type AccountInput=z.infer<typeof command>;
export function accountInput(raw:unknown):AccountInput{const r=command.safeParse(raw);if(!r.success)throw new AuthError(422,'VALIDATION_FAILED','Provide the reviewed account, role, current version and reason.');return r.data;}
export function accountQuery(raw:unknown){const r=z.object({q:z.string().trim().max(160).default(''),role:role.or(z.literal('all')).default('all'),status:z.enum(['all','active','disabled','pending']).default('all'),offset:z.coerce.number().int().min(0).max(10000).default(0),limit:z.coerce.number().int().min(1).max(100).default(25)}).strict().safeParse(raw);if(!r.success)throw new AuthError(422,'VALIDATION_FAILED','Use bounded account filters and pagination.');return r.data;}
