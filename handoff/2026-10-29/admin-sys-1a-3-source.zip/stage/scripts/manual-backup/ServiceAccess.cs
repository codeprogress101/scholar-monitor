using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
namespace LdssManualBackup {
 public static class ServiceAccess {
  [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenSCManager(string machine,string database,uint access);
  [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr OpenService(IntPtr manager,string name,uint access);
  [DllImport("advapi32.dll")] static extern bool CloseServiceHandle(IntPtr h);
  [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string text,uint revision,out IntPtr descriptor,out uint size);
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool SetServiceObjectSecurity(IntPtr service,uint information,IntPtr descriptor);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr memory);
  public static void SetAcl(string text){IntPtr descriptor;uint size;if(!ConvertStringSecurityDescriptorToSecurityDescriptor(text,1,out descriptor,out size))throw new InvalidOperationException("Service ACL conversion failed");try{IntPtr m=OpenSCManager(null,null,1);if(m==IntPtr.Zero)throw new InvalidOperationException("SCM unavailable");try{IntPtr s=OpenService(m,"LDSSIPUATBackup",0xf01ff);if(s==IntPtr.Zero)throw new InvalidOperationException("Service authority unavailable");try{if(!SetServiceObjectSecurity(s,7,descriptor))throw new InvalidOperationException("Service ACL failed");}finally{CloseServiceHandle(s);}}finally{CloseServiceHandle(m);}}finally{LocalFree(descriptor);}}
  public static int Probe(SafeAccessTokenHandle token,uint access){int result=-1;WindowsIdentity.RunImpersonated(token,()=>{IntPtr m=OpenSCManager(null,null,1);if(m==IntPtr.Zero){result=Marshal.GetLastWin32Error();return;}try{IntPtr s=OpenService(m,"LDSSIPUATBackup",access);if(s==IntPtr.Zero)result=Marshal.GetLastWin32Error();else{CloseServiceHandle(s);result=0;}}finally{CloseServiceHandle(m);}});return result;}
 }
}
