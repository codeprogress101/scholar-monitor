// Fixed Windows service wrapper. Worker Node, dependencies and tools are immutable to the API.
using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Cryptography;
using System.ServiceProcess;
using System.Web.Script.Serialization;
using System.Collections.Generic;
namespace LdssManualBackup {
 sealed class Host:ServiceBase {
  const string Root="C:\\ProgramData\\LDSS-IPUAT-BackupWorker";
  [StructLayout(LayoutKind.Sequential)] struct BasicLimits{public long processTime,jobTime;public uint flags;public UIntPtr minimum,maximum;public uint active;public UIntPtr affinity;public uint priority,scheduling;}
  [StructLayout(LayoutKind.Sequential)] struct Counters{public ulong readOps,writeOps,otherOps,readBytes,writeBytes,otherBytes;}
  [StructLayout(LayoutKind.Sequential)] struct ExtendedLimits{public BasicLimits basic;public Counters io;public UIntPtr processMemory,jobMemory,peakProcess,peakJob;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr security,string name);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int kind,ref ExtendedLimits limits,uint size);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  internal static IntPtr BindJob(Process process){IntPtr handle=CreateJobObject(IntPtr.Zero,null);var limits=new ExtendedLimits{basic=new BasicLimits{flags=0x2000}};if(handle==IntPtr.Zero||!SetInformationJobObject(handle,9,ref limits,(uint)Marshal.SizeOf(typeof(ExtendedLimits)))||!AssignProcessToJobObject(handle,process.Handle)){if(handle!=IntPtr.Zero)CloseHandle(handle);throw new IOException();}return handle;}
  internal static void ReleaseJob(IntPtr handle){CloseHandle(handle);}
  Process child;IntPtr job=IntPtr.Zero;Dictionary<string,object> config;
  static string Hash(string p){using(var s=File.OpenRead(p))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant();}
  public Host(){ServiceName="LDSSIPUATBackup";AutoLog=false;CanStop=true;}
  protected override void OnStart(string[] args){try{
   if(args.Length!=0)throw new InvalidOperationException();var json=new JavaScriptSerializer{MaxJsonLength=4194304};config=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Root+"\\secrets\\manual-backup-service.json"));
   if(WindowsIdentity.GetCurrent().User.Value!=(string)config["workerSid"]||new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new InvalidOperationException();
   string runtime=Root+"\\bin\\runtime";if((string)config["runtime"]!=runtime)throw new InvalidOperationException();
   var files=json.Deserialize<Dictionary<string,string>>(File.ReadAllText(runtime+"\\worker-integrity.json"));foreach(var entry in files){string target=Path.GetFullPath(Path.Combine(runtime,entry.Key));if(!target.StartsWith(runtime+"\\",StringComparison.OrdinalIgnoreCase)||Hash(target)!=entry.Value)throw new InvalidOperationException();}
   var start=new ProcessStartInfo(runtime+"\\bin\\node.exe","\""+runtime+"\\scripts\\manual-backup\\runtime.mjs\""){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=runtime,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
   start.EnvironmentVariables.Clear();start.EnvironmentVariables["SystemRoot"]=Environment.GetFolderPath(Environment.SpecialFolder.Windows);start.EnvironmentVariables["PATH"]=start.EnvironmentVariables["SystemRoot"]+"\\System32";start.EnvironmentVariables["TEMP"]=Root+"\\jobs\\temp";start.EnvironmentVariables["TMP"]=Root+"\\jobs\\temp";
   child=Process.Start(start);job=BindJob(child);child.StandardInput.Write("BEGIN\n");child.StandardInput.Flush();child.StandardInput.Close();
   child.ErrorDataReceived+=(s,e)=>{};child.BeginErrorReadLine();var ready=child.StandardOutput.ReadLineAsync();if(!ready.Wait(10000)||ready.Result!="{\"ready\":true}")throw new IOException();
   child.EnableRaisingEvents=true;child.Exited+=(s,e)=>{ExitCode=1;Stop();};
  }catch{OnStop();throw new InvalidOperationException("Manual backup service readiness failed; private details withheld.");}}
  protected override void OnStop(){if(job!=IntPtr.Zero){CloseHandle(job);job=IntPtr.Zero;}if(child!=null){try{if(!child.HasExited)child.Kill();}catch{}child.Dispose();child=null;}}
  static void Main(){ServiceBase.Run(new Host());}
 }
}
