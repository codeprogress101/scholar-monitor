import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import tls from 'node:tls';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {startIpc} from './transport.mjs';
import {requestTls} from '../../server/manual-backups/transport.ts';
const callIpc=(config,request)=>requestTls(config,config.pfx,request);
test('real mutual TLS: peer validation, bounded frames and exact protocol',async t=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'ldss-backup-tls-'));const helper=fileURLToPath(new URL('./New-IpcCertificates.ps1',import.meta.url));
 try{
  for(const p of['server','client','other-server','other-client'])await fs.mkdir(path.join(root,p));
  const ps=p=>"'"+p.replaceAll("'","''")+"'";
  execFileSync('powershell.exe',['-NoProfile','-Command',`. ${ps(helper)};New-IpcCertificates ${ps(path.join(root,'server'))} ${ps(path.join(root,'client'))}|Out-Null;New-IpcCertificates ${ps(path.join(root,'other-server'))} ${ps(path.join(root,'other-client'))}|Out-Null`],{windowsHide:true,stdio:'pipe'});
  const serverConfig=JSON.parse(await fs.readFile(path.join(root,'server/manual-backup-tls.json'),'utf8')),client=JSON.parse(await fs.readFile(path.join(root,'client/api-client.json'),'utf8')),other=JSON.parse(await fs.readFile(path.join(root,'other-client/api-client.json'),'utf8'));
  let calls=0;const server=await startIpc({port:0,options:{pfx:await fs.readFile(serverConfig.serverPfx),passphrase:serverConfig.passphrase,ca:serverConfig.ca},clientFingerprint:serverConfig.clientFingerprint,worker:{request:async r=>{calls++;return{state:'queued',received:r.op};}},operatorStatus:async()=>({sourceMetadataVerified:true,offHostRecoveryVerified:false})});
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  client.port=server.address().port;client.pfx=await fs.readFile(client.clientPfx);
  const response=await callIpc(client,{op:'list',principal:{}});assert.equal(response.received,'list');assert.equal(calls,1);
  await assert.rejects(callIpc({...client,serverFingerprint:'0'.repeat(64)},{op:'list'}));assert.equal(calls,1,'Server pin failure must not transmit request');
  await assert.rejects(callIpc({...client,pfx:await fs.readFile(other.clientPfx),passphrase:other.passphrase},{op:'list'}));assert.equal(calls,1,'Wrong client certificate rejected');
  const status=await callIpc(client,{op:'operator-status'});assert.equal(status.offHostRecoveryVerified,false);assert.equal(calls,1,'Health cannot dispatch a backup');
  await assert.rejects(callIpc(client,{op:'list',padding:'x'.repeat(9000)}));assert.equal(calls,1);
  await new Promise(resolve=>{const socket=tls.connect({host:'127.0.0.1',port:client.port,servername:'ldss-ipuat-backup',pfx:client.pfx,passphrase:client.passphrase,ca:client.ca,rejectUnauthorized:true},()=>{const frame=Buffer.alloc(4);frame.writeUInt32LE(8193);socket.write(frame);});socket.on('error',()=>{});socket.on('close',resolve);socket.setTimeout(2000,()=>socket.destroy());});assert.equal(calls,1,'Oversized frame never reaches worker');
 }finally{assert.equal(path.dirname(path.resolve(root)),path.resolve(os.tmpdir()));assert.ok(path.basename(root).startsWith('ldss-backup-tls-'));await fs.rm(root,{recursive:true});}
});
