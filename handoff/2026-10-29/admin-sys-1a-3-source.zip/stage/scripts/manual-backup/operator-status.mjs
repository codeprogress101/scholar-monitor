import fs from 'node:fs/promises';
import {localTransport} from './runtime/dist/server/manual-backups/transport.js';
try{const config=JSON.parse(await fs.readFile('C:/ProgramData/LDSS-IPUAT-BackupWorker/bin/api-client.json','utf8'));if(config.port!==3041)throw new Error();const result=await localTransport()({op:'operator-status'});process.stdout.write(JSON.stringify({result}));}catch{process.stderr.write('Worker readiness unavailable.\n');process.exitCode=1;}
