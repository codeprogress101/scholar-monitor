import mysql from 'mysql2/promise';
import {readFile,mkdir,lstat,realpath,stat} from 'node:fs/promises';
import {createHash,hkdfSync} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {createBackup,unseal,BACKUP_LIMITS} from '../backup-lib.mjs';
import {JobStore,BackupFault,uuid} from './job-store.mjs';
import {schemaDigest,readSchemaDigest} from './source-meta.mjs';
import {startIpc} from './transport.mjs';
import {BackupWorker} from './worker.mjs';
const hash=value=>createHash('sha256').update(value).digest('hex');
export async function createRuntime(config,key,{initialize=true}={}){
 const pool=mysql.createPool({...config.connection,jsonStrings:true,timezone:'Z',connectionLimit:2,queueLimit:16,waitForConnections:true,connectTimeout:3000,multipleStatements:false});
 const sourceVersion=hash(JSON.stringify({database:config.connection.database,journal:config.journalHash,schema:config.schemaHash,objects:config.objects,release:config.releaseHash,contract:'manual-backup/v1'}));
 const authorize=async principal=>{if(!principal||Object.keys(principal).some(k=>!['userId','tokenHash','accountVersion'].includes(k))||!uuid(principal.userId)||!/^[a-f0-9]{64}$/.test(principal.tokenHash)||!Number.isSafeInteger(principal.accountVersion))throw new BackupFault('SESSION_EXPIRED');
 const [[row]]=await pool.execute("SELECT u.version,u.disabled_at,s.user_id FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.user_id=? AND s.revoked_at IS NULL AND s.expires_at>UTC_TIMESTAMP(6) AND s.last_seen_at>DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 30 MINUTE)",[principal.tokenHash,principal.userId]);
 if(!row||row.disabled_at||Number(row.version)!==principal.accountVersion)throw new BackupFault('SESSION_EXPIRED');
 const [[grant]]=await pool.execute("SELECT COUNT(*) n FROM user_roles r JOIN role_permissions p ON p.role_code=r.role_code WHERE r.user_id=? AND r.role_code='system_admin' AND r.revoked_at IS NULL AND p.permission_code='users.manage'",[principal.userId]);
 if(!Number(grant.n))throw new BackupFault('PERMISSION_DENIED');};
 const authorizeJob=async job=>{const [[row]]=await pool.execute("SELECT u.version FROM users u JOIN user_roles r ON r.user_id=u.id JOIN role_permissions p ON p.role_code=r.role_code WHERE u.id=? AND u.disabled_at IS NULL AND r.revoked_at IS NULL AND r.role_code='system_admin' AND p.permission_code='users.manage'",[job.actorId]);if(!row||Number(row.version)!==job.actorVersion)throw new BackupFault('BACKUP_AUTHORITY_UNAVAILABLE');};
 const receipt=(row,actorId,key)=>{const r=typeof row.result==='string'?JSON.parse(row.result):row.result;if(r.kind!=='manual-backup/v1'||!uuid(r.id)||!uuid(actorId)||!uuid(key)||typeof r.reason!=='string'||r.reason.length<5||r.reason.length>500||!/^[a-f0-9]{64}$/.test(r.sourceVersion))throw new BackupFault('IDEMPOTENCY_CONFLICT');const body={reason:r.reason,confirmed:true,sourceVersion:r.sourceVersion};if(hash(JSON.stringify({kind:'manual-backup/v1',actor:actorId,body}))!==row.payload_hash)throw new BackupFault('IDEMPOTENCY_CONFLICT');return{id:r.id,actorId,key,hash:row.payload_hash,reason:r.reason,sourceVersion:r.sourceVersion,createdAt:row.created_at};};
 const admission=async(a,p)=>{const [[row]]=await pool.execute("SELECT payload_hash,result,DATE_FORMAT(created_at,'%Y-%m-%dT%H:%i:%s.%fZ') created_at FROM configuration_commands WHERE actor_id=? AND request_id=?",[p.userId,a.key]);if(!row||row.payload_hash!==a.hash)throw new BackupFault('IDEMPOTENCY_CONFLICT');const value=receipt(row,p.userId,a.key);if(value.id!==a.id)throw new BackupFault('IDEMPOTENCY_CONFLICT');return{...value,actorVersion:p.accountVersion};};
 const admissions=async()=>{const [rows]=await pool.query("SELECT actor_id,request_id,payload_hash,result,DATE_FORMAT(created_at,'%Y-%m-%dT%H:%i:%s.%fZ') created_at FROM configuration_commands WHERE JSON_UNQUOTE(JSON_EXTRACT(result,'$.kind'))='manual-backup/v1' ORDER BY created_at DESC,request_id,actor_id LIMIT 501");if(rows.length>500)throw new BackupFault('HISTORY_CAPACITY');return rows.map(row=>receipt(row,row.actor_id,row.request_id));};
 const checkSource=async()=>{const db=await pool.getConnection();try{
 const [[identity]]=await db.query('SELECT DATABASE() db,@@hostname host,@@port port,CURRENT_USER() account');if(identity.account!==config.connection.user+'@localhost'||identity.db!==config.connection.database||identity.host!==config.host||Number(identity.port)!==config.connection.port)throw new BackupFault('SOURCE_CHANGED');
 const [journal]=await db.query('SELECT version,checksum FROM schema_migrations ORDER BY version');if(hash(JSON.stringify(journal))!==config.journalHash)throw new BackupFault('SOURCE_CHANGED');
 const [[counts]]=await db.query("SELECT (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE='BASE TABLE') tables_n,(SELECT COUNT(*) FROM information_schema.VIEWS WHERE TABLE_SCHEMA=DATABASE()) views_n,(SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()) triggers_n,(SELECT COUNT(*) FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA=DATABASE()) routines_n,(SELECT COUNT(*) FROM information_schema.EVENTS WHERE EVENT_SCHEMA=DATABASE()) events_n");
 for(const k of['tables','views','triggers','routines','events'])if(Number(counts[k+'_n'])!==config.objects[k])throw new BackupFault('SOURCE_CHANGED');
 // A source-only identity must have complete metadata authority, not a false zero.
 const [grants]=await db.query('SELECT PRIVILEGE_TYPE FROM information_schema.SCHEMA_PRIVILEGES WHERE TABLE_SCHEMA=DATABASE() AND GRANTEE=CONCAT(CHAR(39),SUBSTRING_INDEX(CURRENT_USER(),CHAR(64),1),CHAR(39),CHAR(64),CHAR(39),SUBSTRING_INDEX(CURRENT_USER(),CHAR(64),-1),CHAR(39))');
 const actual=new Set(grants.map(g=>g.PRIVILEGE_TYPE)),expected=new Set(['SELECT','SHOW VIEW','LOCK TABLES','TRIGGER','EVENT','ALTER ROUTINE']);
 if(actual.size!==expected.size||[...expected].some(p=>!actual.has(p)))throw new BackupFault('BACKUP_AUTHORITY_UNAVAILABLE');
 const grantee="'"+config.connection.user+"'@'localhost'";
 const [global]=await db.execute("SELECT PRIVILEGE_TYPE,IS_GRANTABLE FROM information_schema.USER_PRIVILEGES WHERE GRANTEE=?",[grantee]);if(global.some(g=>g.PRIVILEGE_TYPE!=='USAGE'||g.IS_GRANTABLE!=='NO'))throw new BackupFault('BACKUP_AUTHORITY_UNAVAILABLE');
 for(const table of['SCHEMA_PRIVILEGES','TABLE_PRIVILEGES','COLUMN_PRIVILEGES']){const [rows]=await db.execute('SELECT * FROM information_schema.'+table+' WHERE GRANTEE=?'+(table==='SCHEMA_PRIVILEGES'?" AND (TABLE_SCHEMA<>DATABASE() OR IS_GRANTABLE<>'NO')":''),[grantee]);if(rows.length)throw new BackupFault('BACKUP_AUTHORITY_UNAVAILABLE');}
 if(await readSchemaDigest(db,config.connection.database)!==config.schemaHash)throw new BackupFault('SOURCE_CHANGED');
 return{sourceVersion,tables:config.objects.tables};
 }finally{db.release();}};
 await mkdir(config.archives,{recursive:true});if((await lstat(config.archives)).isSymbolicLink())throw new BackupFault('STORAGE_UNAVAILABLE');const archives=await realpath(config.archives);
 const capture=async id=>{const directory=path.join(archives,id);await mkdir(directory,{recursive:false});return createBackup(key,{connection:config.connection,directory,dumpTool:config.dumpTool,args:['--no-defaults','--host=127.0.0.1','--port='+config.connection.port,'--user='+config.connection.user,'--default-character-set=utf8mb4']});};
 const verify=async(result,id)=>{const real=await realpath(result.file),dir=path.join(archives,id);if(!real.startsWith(dir+path.sep)||(await lstat(real)).isSymbolicLink()||(await stat(real)).size>BACKUP_LIMITS.archiveBytes)throw new BackupFault('ARCHIVE_INVALID');const bytes=await readFile(real),payload=unseal(bytes,key,config.connection.database);if(schemaDigest(payload.inventory)!==config.schemaHash)throw new BackupFault('SOURCE_CHANGED');if(payload.inventory.tables.length!==config.objects.tables||payload.inventory.triggers.length!==config.objects.triggers||payload.inventory.views.length!==config.objects.views)throw new BackupFault('ARCHIVE_INVALID');return{bytes:bytes.length,tables:payload.inventory.tables.length,sha256:hash(bytes),file:path.basename(real)};};
 const store=new JobStore(config.jobs,Buffer.from(hkdfSync('sha256',key,Buffer.alloc(0),Buffer.from('LDSS manual backup journal v1'),32)));
 const worker=new BackupWorker({store,authorize,authorizeJob,admission,admissions,checkSource,capture,verify});if(initialize)await worker.initialize();
 return{worker,store,sourceVersion,close:()=>pool.end()};
}
async function main(){
 await new Promise((resolve,reject)=>{let buffer='';const ended=()=>reject(new Error('Service startup channel closed'));const data=part=>{buffer+=part.toString('utf8');if(buffer.length>6||!('BEGIN\n').startsWith(buffer)){reject(new Error('Service startup refused'));process.stdin.destroy();return;}if(buffer==='BEGIN\n'){process.stdin.removeListener('data',data);process.stdin.removeListener('end',ended);resolve();}};process.stdin.on('data',data);process.stdin.once('end',ended);});
 const root='C:/ProgramData/LDSS-IPUAT-BackupWorker';
 const config=JSON.parse(await readFile(root+'/secrets/manual-backup.json','utf8'));
 if(config.connection.database!=='ldss_restore_1793167108097_2b47a744'||config.connection.host!=='127.0.0.1'||config.connection.port!==3306||!/^ldss_bkw_[a-f0-9]{12}$/.test(config.connection.user)||config.host!=='DESKTOP-BPLJKRP'||config.jobs!==root+'/jobs/manual'||config.archives!==root+'/archives/manual'||config.keyFile!==root+'/secrets/backup.key'||config.localUatOnly!==true||config.offHostRecoveryVerified!==false||config.dumpTool!==root+'/bin/runtime/bin/mysqldump.exe')throw new Error('Worker binding unavailable');
 const key=await readFile(config.keyFile);if(key.length!==32)throw new Error('Worker key unavailable');
 const channel=JSON.parse(await readFile(root+'/secrets/manual-backup-tls.json','utf8'));
 if(channel.version!==1||channel.port!==3041||channel.serverPfx.replaceAll('\\','/').toLowerCase()!=='c:/programdata/ldss-ipuat-backupworker/secrets/ipc-server.pfx'||!/^[a-f0-9]{64}$/.test(channel.clientFingerprint))throw new Error('IPC binding unavailable');
 const pfx=await readFile(channel.serverPfx);if(pfx.length>65536)throw new Error('IPC certificate bound');
 let runtime;
 const server=await startIpc({port:3041,options:{pfx,passphrase:channel.passphrase,ca:channel.ca},clientFingerprint:channel.clientFingerprint,worker:{request:r=>{if(!runtime)throw new BackupFault('WORKER_UNAVAILABLE');return runtime.worker.request(r);}},operatorStatus:async()=>({...(await runtime.worker.checkSource()),sourceMetadataVerified:true,keyLengthVerified:true,localUatOnly:true,offHostRecoveryVerified:false})});
 try{runtime=await createRuntime(config,key,{initialize:false});await runtime.worker.checkSource();await runtime.worker.initialize();}catch(e){server.close();if(runtime)await runtime.close();throw e;}
 process.stdout.write(JSON.stringify({ready:true})+'\n');
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)main().catch(()=>{process.stderr.write('Backup worker unavailable; private details withheld.\n');process.exitCode=1;});
