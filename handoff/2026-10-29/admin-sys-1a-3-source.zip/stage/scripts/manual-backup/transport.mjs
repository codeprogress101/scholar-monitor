import tls from 'node:tls';
const normalize=s=>String(s).replaceAll(':','').toLowerCase();
export async function startIpc({port,options,clientFingerprint,worker,operatorStatus}){
 if(!Number.isInteger(port)||(port!==0&&port<1024)||port>65535||!/^[a-f0-9]{64}$/.test(clientFingerprint))throw new Error('IPC binding invalid');
 const server=tls.createServer({...options,minVersion:'TLSv1.2',requestCert:true,rejectUnauthorized:true},socket=>{
  if(!socket.authorized||normalize(socket.getPeerCertificate().fingerprint256)!==clientFingerprint){socket.destroy();return;}
  let buffer=Buffer.alloc(0),handled=false;socket.setTimeout(5000,()=>socket.destroy());socket.on('error',()=>{});
  socket.on('data',async part=>{if(handled){socket.destroy();return;}buffer=Buffer.concat([buffer,part]);if(buffer.length>8196){socket.destroy();return;}if(buffer.length<4)return;const size=buffer.readUInt32LE(0);if(size<1||size>8192){socket.destroy();return;}if(buffer.length<size+4)return;if(buffer.length!==size+4){socket.destroy();return;}handled=true;
   let result;try{const request=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(buffer.subarray(4)));result={result:request?.op==='operator-status'&&Object.keys(request).length===1?await operatorStatus():await worker.request(request)};}catch(e){const allowed=['SESSION_EXPIRED','PERMISSION_DENIED','SOURCE_CHANGED','REQUEST_INVALID','IDEMPOTENCY_CONFLICT','HISTORY_CAPACITY','JOB_NOT_FOUND'];result={error:allowed.includes(e.code)?e.code:'WORKER_UNAVAILABLE'};}
   const data=Buffer.from(JSON.stringify(result));if(data.length>262144){socket.destroy();return;}const sizeBytes=Buffer.alloc(4);sizeBytes.writeUInt32LE(data.length);if(!socket.destroyed)socket.end(Buffer.concat([sizeBytes,data]));
  });
 });server.maxConnections=4;server.on('tlsClientError',()=>{});await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});return server;
}
