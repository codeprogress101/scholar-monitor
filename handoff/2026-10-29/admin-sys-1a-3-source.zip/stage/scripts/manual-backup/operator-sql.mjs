// Invoked only from the sealed elevated installer. Never imported by the API.
import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
import {randomBytes,createHash} from 'node:crypto';
const require=createRequire(new URL('./runtime/package.json',import.meta.url));
const mysql=require('mysql2/promise');
const {readSchemaDigest}=await import('./runtime/scripts/manual-backup/source-meta.mjs');
const hash=value=>createHash('sha256').update(value).digest('hex');
let db;
try{
 const chunks=[];let length=0;for await(const chunk of process.stdin){length+=chunk.length;if(length>4096)throw new Error();chunks.push(chunk);}
 const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(Object.keys(input).some(k=>k!=='password')||typeof input.password!=='string'||input.password.length>256)throw new Error();
 const profile=JSON.parse(await fs.readFile(new URL('./profile.json',import.meta.url),'utf8'));
 if(profile.database!=='ldss_restore_1793167108097_2b47a744'||profile.host!=='DESKTOP-BPLJKRP'||!/^ldss_bkw_[a-f0-9]{12}$/.test(profile.sqlUser))throw new Error();
 db=await mysql.createConnection({host:'127.0.0.1',port:3306,user:'root',password:input.password,database:profile.database,jsonStrings:true,timezone:'Z',multipleStatements:false});
 const [[identity]]=await db.query('SELECT CURRENT_USER() account_name,DATABASE() db,@@hostname host,@@port port');
 if(identity.account_name!=='root@localhost'||identity.db!==profile.database||identity.host!==profile.host||Number(identity.port)!==3306)throw new Error();
 const [journal]=await db.query('SELECT version,checksum FROM schema_migrations ORDER BY version');
 if(hash(JSON.stringify(journal))!==profile.journalHash||await readSchemaDigest(db,profile.database)!==profile.schemaHash)throw new Error();
 const [existing]=await db.execute('SELECT User FROM mysql.user WHERE User=?',[profile.sqlUser]);if(existing.length)throw new Error();
 const password=randomBytes(32).toString('base64url'),root='C:/ProgramData/LDSS-IPUAT-BackupWorker';
 const config={connection:{host:'127.0.0.1',port:3306,user:profile.sqlUser,password,database:profile.database},host:profile.host,journalHash:profile.journalHash,schemaHash:profile.schemaHash,objects:profile.objects,releaseHash:profile.releaseHash,jobs:root+'/jobs/manual',archives:root+'/archives/manual',keyFile:root+'/secrets/backup.key',dumpTool:root+'/bin/runtime/bin/mysqldump.exe',localUatOnly:true,offHostRecoveryVerified:false};
 // Exclusive private state precedes nontransactional SQL account creation. Never reset/adopt.
 await fs.writeFile(root+'/secrets/manual-backup.json',JSON.stringify(config),{flag:'wx',mode:0o600});
 await db.query("CREATE USER ?@'localhost' IDENTIFIED BY ?",[profile.sqlUser,password]);
 await db.query('GRANT SELECT, SHOW VIEW, LOCK TABLES, TRIGGER, EVENT, ALTER ROUTINE ON `'+profile.database+"`.* TO ?@'localhost'",[profile.sqlUser]);
 await fs.writeFile(root+'/secrets/manual-backup-sql-receipt.json',JSON.stringify({version:1,user:profile.sqlUser,database:profile.database,at:new Date().toISOString(),sourceOnly:true,metadataDdlAuthority:['TRIGGER','EVENT','ALTER ROUTINE']}),{flag:'wx',mode:0o600});
 process.stdout.write(JSON.stringify({sourceSqlConfigured:true,sourceOnly:true}));
}catch{process.stderr.write('Source SQL installation refused or incomplete. Preserve protected state; no automatic retry or password reset.\n');process.exitCode=1;}
finally{if(db)await db.end();}
