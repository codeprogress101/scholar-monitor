#Requires -Version 5.1
# Execute these hash-verified bytes in memory. No self-elevation or policy bypass.
[CmdletBinding()]
param([ValidateSet('Inspect','Install','Verify')][string]$Mode='Inspect',[switch]$AcknowledgeSourceMetadataDdlAuthority)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if(-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or -not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -ne 'Desktop'){throw 'ELEVATION_REQUIRED: no service, SQL capability or protected staging was changed.'}
$source='C:\xampp\htdocs\scholar_monitor\output\admin-sys-1a-3-20261029\development-1\deployment-package'
$destination='C:\ProgramData\LDSS-IPUAT-ManualBackupInstaller-v1'
$expectedManifest='MANIFEST_SHA256_PLACEHOLDER'
function Hash-Bytes([byte[]]$Bytes){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function No-Reparse([string]$Path){$p=[IO.Path]::GetFullPath($Path);while($p){if(Test-Path -LiteralPath $p){if((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse path refused.'}};$p=[IO.Path]::GetDirectoryName($p)}}
No-Reparse $source;No-Reparse $destination
$bytes=[IO.File]::ReadAllBytes((Join-Path $source 'manifest.json'))
if($bytes.Length -gt 4194304 -or (Hash-Bytes $bytes) -cne $expectedManifest){throw 'Installer manifest integrity mismatch.'}
$manifest=[Text.Encoding]::UTF8.GetString($bytes)|ConvertFrom-Json
if($manifest.files.Count -lt 10 -or $manifest.files.Count -gt 25000){throw 'Installer file count outside reviewed bounds.'}
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetSecurityDescriptorSddlForm(('O:'+$identity.User.Value+'G:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;RC;;;OW)'))
$modules=$env:PSModulePath;$temp=$env:TEMP;$tmp=$env:TMP
try{
 $env:PSModulePath='C:\Windows\System32\WindowsPowerShell\v1.0\Modules'
 if(-not(Test-Path -LiteralPath $destination)){[void][IO.Directory]::CreateDirectory($destination,$acl)}
 if((Get-Acl -LiteralPath $destination).Sddl -cne $acl.Sddl){throw 'Existing installer staging ACL mismatch; no adoption.'}
 $allowed=@{};$total=[long]0
 foreach($entry in $manifest.files){
  if($entry.path -notmatch '^[a-zA-Z0-9_@.\-/]+$' -or $entry.path -match '(^|/)\.\.(/|$)' -or $entry.sha256 -notmatch '^[a-f0-9]{64}$' -or $entry.bytes -gt 134217728 -or $entry.bytes -lt 0){throw 'Invalid package entry.'}
  if($allowed.ContainsKey($entry.path.ToLowerInvariant())){throw 'Duplicate package path.'};$allowed[$entry.path.ToLowerInvariant()]=$true;$total+=$entry.bytes
  if($total -gt 536870912){throw 'Installer package exceeds 512 MiB bound.'}
  $original=[IO.Path]::GetFullPath((Join-Path $source $entry.path));$target=[IO.Path]::GetFullPath((Join-Path $destination $entry.path))
  if(-not $original.StartsWith($source+'\',[StringComparison]::OrdinalIgnoreCase) -or -not $target.StartsWith($destination+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Package path escape.'}
  No-Reparse $original;No-Reparse $target
  $data=[IO.File]::ReadAllBytes($original)
  if($data.Length -ne $entry.bytes -or (Hash-Bytes $data) -cne $entry.sha256){throw 'Payload changed; no service or SQL action was performed.'}
  [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
  if(Test-Path -LiteralPath $target){if((Hash-Bytes ([IO.File]::ReadAllBytes($target))) -cne $entry.sha256){throw 'Existing protected payload differs; preserve it.'}}
  else{$s=[IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$s.Write($data,0,$data.Length)}finally{$s.Dispose()}}
 }
 $targetManifest=Join-Path $destination 'manifest.json'
 if(Test-Path -LiteralPath $targetManifest){if((Hash-Bytes ([IO.File]::ReadAllBytes($targetManifest))) -cne $expectedManifest){throw 'Existing manifest differs.'}}
 else{[IO.File]::WriteAllBytes($targetManifest,$bytes)}
 $protectedTemp=Join-Path $destination 'tmp'
 if(-not(Test-Path -LiteralPath $protectedTemp)){[void][IO.Directory]::CreateDirectory($protectedTemp,$acl)}
 No-Reparse $protectedTemp;if((Get-Acl -LiteralPath $protectedTemp).Sddl -cne $acl.Sddl){throw 'Protected compiler ACL mismatch.'}
 foreach($file in Get-ChildItem -LiteralPath $destination -Recurse -Force){if($file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse protected package entry.'};if(-not $file.PSIsContainer -and -not $file.FullName.StartsWith($protectedTemp+'\',[StringComparison]::OrdinalIgnoreCase)){ $relative=$file.FullName.Substring($destination.Length+1).Replace('\','/').ToLowerInvariant();if($relative -ne 'manifest.json' -and -not $allowed.ContainsKey($relative)){throw 'Unexpected protected package file; preserve it.'}}}
 $env:TEMP=$protectedTemp;$env:TMP=$protectedTemp
 & (Join-Path $destination 'Install-Worker.ps1') -Mode $Mode -AcknowledgeSourceMetadataDdlAuthority:$AcknowledgeSourceMetadataDdlAuthority
}finally{$env:PSModulePath=$modules;$env:TEMP=$temp;$env:TMP=$tmp}
