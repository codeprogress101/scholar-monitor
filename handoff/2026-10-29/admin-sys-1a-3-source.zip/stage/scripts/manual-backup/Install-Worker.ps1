#Requires -Version 5.1
# Execute only the protected, manifest-verified copy through the reviewed bootstrap.
[CmdletBinding()]
param([ValidateSet('Inspect','Install','Verify')][string]$Mode='Inspect',[switch]$AcknowledgeSourceMetadataDdlAuthority)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$script:Package='C:\ProgramData\LDSS-IPUAT-ManualBackupInstaller-v1'
$script:Root='C:\ProgramData\LDSS-IPUAT-BackupWorker'
$script:InstallKey='SOFTWARE\LDSS_IPUAT_ManualBackupService_v1'
function Require([bool]$Value,[string]$Message){if(-not $Value){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function No-Reparse([string]$Path){$p=[IO.Path]::GetFullPath($Path);while($p){if(Test-Path -LiteralPath $p){Require (-not ((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Reparse path refused.'};$p=[IO.Path]::GetDirectoryName($p)}}
function RegistryBase{[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)}
function RegistryAcl([string]$Sid){$a=[Security.AccessControl.RegistrySecurity]::new();$a.SetSecurityDescriptorSddlForm(('O:'+$Sid+'G:BAD:P(A;CI;KA;;;SY)(A;CI;KA;;;BA)(A;CI;RC;;;OW)'));return $a}
function DirectoryAcl([string]$Sid,[string]$WorkerSid=''){$a=[Security.AccessControl.DirectorySecurity]::new();$worker=if($WorkerSid){'(A;OICI;0x1200a9;;;'+$WorkerSid+')'}else{''};$a.SetSecurityDescriptorSddlForm(('O:'+$Sid+'G:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;RC;;;OW)'+$worker));return $a}
function Registration([string]$Subkey,[string]$Sid){$base=RegistryBase;try{$key=$base.OpenSubKey($Subkey);if(-not $key){return $null};try{$sections=[Security.AccessControl.AccessControlSections]::Access -bor [Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Group;Require ($key.GetAccessControl($sections).GetSecurityDescriptorSddlForm($sections) -ceq (RegistryAcl $Sid).Sddl) 'Ownership ACL mismatch.';Require ($key.SubKeyCount -eq 0 -and ($key.GetValueNames() -join '|') -ceq 'Record') 'Unexpected ownership contents.';return ($key.GetValue('Record')|ConvertFrom-Json)}finally{$key.Dispose()}}finally{$base.Dispose()}}
function Save-Registration($Record){$base=RegistryBase;try{$key=$base.OpenSubKey($script:InstallKey,$true);try{$key.SetValue('Record',($Record|ConvertTo-Json -Depth 8 -Compress));$key.Flush()}finally{$key.Dispose()}}finally{$base.Dispose()}}
function Write-New([string]$Path,[string]$Value){$s=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$b=[Text.Encoding]::UTF8.GetBytes($Value);$s.Write($b,0,$b.Length);$s.Flush($true)}finally{$s.Dispose()}}
function Find-Service{try{return Get-Service -Name LDSSIPUATBackup -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -like 'NoServiceFoundForGivenName,*'){return $null};throw}}
function Assert-Target($Profile){
 Require ($env:COMPUTERNAME -ceq 'DESKTOP-BPLJKRP' -and $Profile.database -ceq 'ldss_restore_1793167108097_2b47a744' -and $Profile.localUatOnly -eq $true -and $Profile.offHostRecoveryVerified -eq $false) 'Wrong target or reliance boundary.'
 Require ((Hash 'C:\Users\ADMIN\.ldss\ip-uat-1-20261028\private\runtime-integrity.json') -ceq $Profile.releaseHash) 'Accepted UAT release changed.'
 $running=Get-Content -Raw -LiteralPath C:\Users\ADMIN\.ldss\ip-uat-1-20261028\state\running.json|ConvertFrom-Json
 Require ([int]$running.apiPid -eq [int]$Profile.apiPid -and [int]$running.webPid -eq [int]$Profile.webPid) 'UAT runtime changed.'
 foreach($pair in @(@(3031,[int]$Profile.apiPid),@(5181,[int]$Profile.webPid))){$listeners=@(Get-NetTCPConnection -State Listen -LocalPort $pair[0]);Require ($listeners.Count -eq 1 -and $listeners[0].LocalAddress -ceq '127.0.0.1' -and $listeners[0].OwningProcess -eq $pair[1]) 'UAT listener changed.'}
 $process=Get-Process -Id ([int]$Profile.apiPid);Require ($process.StartTime.ToUniversalTime().ToFileTimeUtc().ToString() -ceq $Profile.apiCreated) 'API process identity changed.'
 $info=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$Profile.apiPid)
 Require ($info.ExecutablePath -ieq 'C:\Users\ADMIN\.ldss\ip-uat-1-20261028\release\bin\node.exe' -and $info.CommandLine -like '*scripts/ip-uat1/api.mjs*') 'Wrong API process.'
}
function Assert-Foundation($Profile,[string]$Sid){
 $r=Registration 'SOFTWARE\LDSS_IPUAT_BackupFoundation_v1' $Sid
 Require ($null -ne $r -and $r.phase -ceq 'FoundationVerified' -and $r.version -ceq 'ADMIN-SYS-1A.2/foundation-v2' -and $r.database -ceq $Profile.database -and $r.root -ceq $script:Root) 'Verified foundation missing or changed.'
 Require ($r.scriptHash -ceq '886a97f9dac0fa1663feb694934e38305c287122a18adb98e26c56b1fbf09f5b' -and $r.profileHash -ceq 'bcdbb67ee2b44e184658f3137178f88652a8c9cfeaaadf03b6716756525a3528') 'Foundation source mismatch.'
 foreach($name in @('apiTokenLimited','workerServiceLogon','apiDenialsVerified','workerProtectedPathDenialsVerified')){Require ($r.proof.$name -eq $true) 'Foundation proof incomplete.'};Require ($r.proof.workerAdministrator -eq $false) 'Worker is not restricted.'
 $u=Get-LocalUser -Name ldss_ipu_bkp
 Require ($u.Enabled -and $u.SID.Value -ceq $r.workerSid -and $u.SID.Value -ceq $Profile.workerSid -and $u.Description -ceq ('LDSS IPUAT '+$r.owner)) 'Worker ownership mismatch.'
 foreach($entry in $r.acls){No-Reparse $entry.path;Require ((Get-Acl -LiteralPath $entry.path).Sddl -ceq $entry.sddl) 'Foundation ACL changed.'}
 foreach($entry in $r.guards){Require ((Get-Acl -LiteralPath $entry.path).Sddl -ceq $entry.after) 'Credential guard changed.'}
 foreach($entry in $r.files){No-Reparse $entry.path;Require ((Hash $entry.path) -ceq $entry.sha256) 'Foundation file changed.'}
 $requiredRights=@('SeServiceLogonRight','SeDenyInteractiveLogonRight','SeDenyRemoteInteractiveLogonRight','SeDenyNetworkLogonRight','SeDenyBatchLogonRight')
 Require ((@([LdssBackupFoundation.Native]::Rights($r.workerSid)|Sort-Object) -join '|') -ceq (($requiredRights|Sort-Object) -join '|')) 'Worker rights changed.'
 foreach($group in Get-LocalGroup){$members=@(Get-LocalGroupMember -Group $group.Name);if(@($members|Where-Object {$_.SID.Value -ceq $r.workerSid}).Count){Require ($group.SID.Value -ceq 'S-1-5-32-545') 'Unexpected worker group.'}}
 No-Reparse ($script:Root+'\secrets\backup.key');Require ((Get-Item -LiteralPath ($script:Root+'\secrets\backup.key')).Length -eq 32) 'Key metadata changed; no key content was read.'
 return $r
}
function Assert-Package($Profile,[string]$Sid){
 Require ([IO.Path]::GetFullPath($PSScriptRoot) -ceq $script:Package) 'Use the protected bootstrap copy.'
 No-Reparse $script:Package;Require ((Get-Acl -LiteralPath $script:Package).Sddl -ceq (DirectoryAcl $Sid).Sddl) 'Installer package ACL differs.'
 $m=Get-Content -Raw -LiteralPath ($script:Package+'\manifest.json')|ConvertFrom-Json
 Require ($m.files.Count -gt 10 -and $m.files.Count -le 25000) 'Package bounds invalid.'
 foreach($entry in $m.files){$file=[IO.Path]::GetFullPath((Join-Path $script:Package $entry.path));Require ($file.StartsWith($script:Package+'\',[StringComparison]::OrdinalIgnoreCase)) 'Package path escape.';No-Reparse $file;Require ((Hash $file) -ceq $entry.sha256) 'Package hash mismatch.'}
 Require ($Profile.apiSid -ceq $Sid) 'Use the reviewed ADMIN operator identity.'
}
function Invoke-Private([string]$Executable,[string]$Arguments,[string]$InputValue){
 $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$Executable;$start.Arguments=$Arguments;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.WorkingDirectory=$script:Package;$start.RedirectStandardInput=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
 $start.EnvironmentVariables.Clear();$start.EnvironmentVariables['SystemRoot']=$env:SystemRoot;$start.EnvironmentVariables['PATH']=$env:SystemRoot+'\System32';$start.EnvironmentVariables['TEMP']=$script:Package+'\tmp';$start.EnvironmentVariables['TMP']=$script:Package+'\tmp'
 $p=[Diagnostics.Process]::Start($start);try{$p.StandardInput.Write($InputValue);$p.StandardInput.Close();$output=$p.StandardOutput.ReadToEndAsync();$errors=$p.StandardError.ReadToEndAsync();Require ($p.WaitForExit(30000)) 'Private setup timed out; inspect protected state.';Require ($p.ExitCode -eq 0) 'Private setup refused or incomplete; credentials/SQL withheld.';Require ($output.Result.Length -lt 16384) 'Oversized setup result.';return ($output.Result|ConvertFrom-Json)}finally{if(-not $p.HasExited){$p.Kill()};$p.Dispose()}
}
function Verify-Service($Profile,$Record){
 $service=Get-CimInstance Win32_Service -Filter "Name='LDSSIPUATBackup'";Require ($null -ne $service -and $service.State -ceq 'Running' -and $service.StartName -ieq ($env:COMPUTERNAME+'\ldss_ipu_bkp') -and $service.PathName -ceq ('"'+$script:Root+'\bin\manual-backup-service.exe"')) 'Owned service is unavailable or changed.'
 Require ((Hash ($script:Root+'\bin\manual-backup-service.exe')) -ceq $Record.serviceHash) 'Installed service hash changed.'
 foreach($entry in (Get-Content -Raw -LiteralPath ($script:Package+'\manifest.json')|ConvertFrom-Json).files|Where-Object {$_.path.StartsWith('runtime/')}){$file=Join-Path ($script:Root+'\bin\runtime') $entry.path.Substring(8);No-Reparse $file;Require ((Hash $file) -ceq $entry.sha256) 'Installed runtime differs.'}
 $token=[LdssBackupFoundation.Native]::ProcessToken([int]$Profile.apiPid)
 try{Require (-not [LdssBackupFoundation.Native]::Elevated($token)) 'API is elevated.';foreach($access in @(2,16,0x40000)){Require ([LdssManualBackup.ServiceAccess]::Probe($token,$access) -eq 5) 'API can change/control worker service.'};Require ([LdssManualBackup.ServiceAccess]::Probe($token,4) -eq 0) 'API cannot query worker status.'}finally{$token.Dispose()}
 $proof=Invoke-Private ($script:Package+'\runtime\bin\node.exe') ('"'+$script:Package+'\operator-status.mjs"') ''
 Require ($proof.result.sourceMetadataVerified -eq $true -and $proof.result.keyLengthVerified -eq $true -and $proof.result.localUatOnly -eq $true -and $proof.result.offHostRecoveryVerified -eq $false) 'Actual worker readiness failed.'
 return [ordered]@{serviceInstalled=$true;workerServiceRunning=$true;actualWorkerSourceCheck=$true;apiServiceControlDenied=$true;localUatOnly=$true;offHostRecoveryVerified=$false;backupApiUiInstalled=$false;automaticBackupSubmitted=$false}
}
function Invoke-Install {
 $id=[Security.Principal.WindowsIdentity]::GetCurrent();$Sid=$id.User.Value
 Require (([Security.Principal.WindowsPrincipal]::new($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -and [Environment]::Is64BitProcess -and $PSVersionTable.PSEdition -eq 'Desktop') 'ELEVATION_REQUIRED: nothing installed.'
 Require ([IO.Path]::GetFullPath($PSScriptRoot) -ceq $script:Package) 'Use the sealed bootstrap.'
 $profile=Get-Content -Raw -LiteralPath ($script:Package+'\profile.json')|ConvertFrom-Json
 Assert-Package $profile $Sid;Assert-Target $profile
 Require ($env:TEMP -ceq $script:Package+'\tmp' -and $env:TMP -ceq $script:Package+'\tmp') 'Compiler location must be protected.'
 if(-not ('LdssBackupFoundation.Native' -as [type])){Add-Type -Path ($script:Package+'\BackupFoundation.Native.cs')}
 if(-not ('LdssManualBackup.ServiceAccess' -as [type])){Add-Type -Path ($script:Package+'\ServiceAccess.cs')}
 $foundation=Assert-Foundation $profile $Sid
 $existing=Registration $script:InstallKey $Sid
 if($existing){Require ($existing.phase -ceq 'Installed' -and $existing.manifestHash -ceq (Hash ($script:Package+'\manifest.json')) -and $existing.foundationOwner -ceq $foundation.owner) 'Incomplete or foreign installation: preserve it; do not retry or reset.';return Verify-Service $profile $existing}
 Require ($Mode -ne 'Verify') 'No installed service receipt.'
 Require ($null -eq (Find-Service)) 'Unexpected existing service; no adoption.'
 Require (@(Get-NetTCPConnection -State Listen -LocalPort 3041 -ErrorAction SilentlyContinue).Count -eq 0) 'IPC port occupied; no service or listener is displaced.'
 foreach($dir in @('archives','jobs')){Require (@(Get-ChildItem -LiteralPath ($script:Root+'\'+$dir) -Force).Count -eq 0) 'Existing backup/job data: preserve it.'}
 Require (@(Get-ChildItem -LiteralPath ($script:Root+'\bin') -Force).Count -eq 1 -and (Test-Path -LiteralPath ($script:Root+'\bin\acl-probe.dat'))) 'Unexpected worker code.'
 Require (@(Get-ChildItem -LiteralPath ($script:Root+'\secrets') -Force).Count -eq 1) 'Unexpected worker secret/configuration; preserve.'
 if($Mode -eq 'Inspect'){return [ordered]@{readyForReviewedInstall=$true;foundationRetained=$true;metadataDdlAuthority=@('TRIGGER','EVENT','ALTER ROUTINE');offHostRecoveryVerified=$false;changed=$false}}
 Require $AcknowledgeSourceMetadataDdlAuthority.IsPresent 'Explicit source metadata DDL acknowledgement is required.'
 $workerPassword=Read-Host 'Existing worker Windows password from your password manager (never send in chat)' -AsSecureString
 $adminPassword=Read-Host 'Local SQL operator password (empty only if that is the established local operator configuration)' -AsSecureString
 $api=$null;$worker=$null;$record=$null;$serviceCreated=$false
 try{
  Require ($workerPassword.Length -ge 32) 'Existing worker password length invalid; no reset.'
  $api=[LdssBackupFoundation.Native]::ProcessToken([int]$profile.apiPid);Require (-not [LdssBackupFoundation.Native]::Elevated($api)) 'API is elevated.'
  $worker=[LdssBackupFoundation.Native]::ServiceToken('ldss_ipu_bkp',$workerPassword);Require (-not [LdssBackupFoundation.Native]::Administrator($worker)) 'Worker has Administrator authority.'
  Require ([LdssBackupFoundation.Native]::Probe($api,($script:Root+'\secrets\backup.key'),1) -eq 5 -and [LdssBackupFoundation.Native]::Probe($worker,($script:Root+'\secrets\backup.key'),1) -eq 0) 'Existing key isolation proof failed.'
  Assert-Target $profile
  [LdssBackupFoundation.Native]::CreateRegistryExclusive($script:InstallKey,(RegistryAcl $Sid).Sddl)
  $record=[pscustomobject]@{version=1;phase='Installing';foundationOwner=$foundation.owner;workerSid=$profile.workerSid;database=$profile.database;manifestHash=(Hash ($script:Package+'\manifest.json'));serviceHash=(Hash ($script:Package+'\service.exe'));sqlUser=$profile.sqlUser;createdAt=[DateTime]::UtcNow.ToString('o')};Save-Registration $record
  [LdssBackupFoundation.Native]::CreateDirectoryExclusive(($script:Root+'\bin\runtime'),(DirectoryAcl $Sid $profile.workerSid).Sddl)
  foreach($entry in (Get-Content -Raw -LiteralPath ($script:Package+'\manifest.json')|ConvertFrom-Json).files|Where-Object {$_.path.StartsWith('runtime/')}){
   $relative=$entry.path.Substring(8);$destination=[IO.Path]::GetFullPath((Join-Path ($script:Root+'\bin\runtime') $relative));Require ($destination.StartsWith($script:Root+'\bin\runtime\',[StringComparison]::OrdinalIgnoreCase)) 'Runtime path escape.'
   $parent=[IO.Path]::GetDirectoryName($destination);No-Reparse $parent;[void][IO.Directory]::CreateDirectory($parent);No-Reparse $destination;$bytes=[IO.File]::ReadAllBytes((Join-Path $script:Package $entry.path));Require ([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLowerInvariant() -ceq $entry.sha256) 'Runtime changed.';$stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
  }
  [IO.File]::Copy(($script:Package+'\service.exe'),($script:Root+'\bin\manual-backup-service.exe'),$false)
  [void][IO.Directory]::CreateDirectory($script:Root+'\jobs\temp')
  . ($script:Package+'\New-IpcCertificates.ps1')
  $certificates=New-IpcCertificates ($script:Root+'\secrets') ($script:Root+'\bin')
  Require ($certificates.transportCertificatesCreated -eq $true) 'IPC certificate setup failed.'
  foreach($name in @('ipc-client.pfx','api-client.json')){$file=$script:Root+'\bin\'+$name;$security=Get-Acl -LiteralPath $file;$rule=[Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($profile.apiSid),[Security.AccessControl.FileSystemRights]::Read,[Security.AccessControl.InheritanceFlags]::None,[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow);$security.AddAccessRule($rule);Set-Acl -LiteralPath $file -AclObject $security;Require ([LdssBackupFoundation.Native]::Probe($api,$file,1) -eq 0 -and [LdssBackupFoundation.Native]::Probe($api,$file,2) -eq 5 -and [LdssBackupFoundation.Native]::Probe($api,$file,0x40000) -eq 5) 'IPC capability ACL failed.'}
  Require ([LdssBackupFoundation.Native]::Probe($api,($script:Root+'\secrets\ipc-server.pfx'),1) -eq 5) 'API can read server private key.'
  $native=[Runtime.InteropServices.Marshal]::SecureStringToGlobalAllocUnicode($adminPassword)
  try{$inputValue=@{password=[Runtime.InteropServices.Marshal]::PtrToStringUni($native)}|ConvertTo-Json -Compress;$sql=Invoke-Private ($script:Package+'\runtime\bin\node.exe') ('"'+$script:Package+'\operator-sql.mjs"') $inputValue;Require ($sql.sourceSqlConfigured -eq $true) 'Source SQL setup incomplete.'}finally{[Runtime.InteropServices.Marshal]::ZeroFreeGlobalAllocUnicode($native);$inputValue=$null}
  $serviceConfig=@{workerSid=$profile.workerSid;apiSid=$profile.apiSid;apiPid=$profile.apiPid;apiCreated=$profile.apiCreated;runtime=$script:Root+'\bin\runtime'}
  Write-New ($script:Root+'\secrets\manual-backup-service.json') ($serviceConfig|ConvertTo-Json -Compress)
  foreach($pair in @(@(($script:Root+'\secrets\manual-backup.json'),1),@(($script:Root+'\bin\runtime\scripts\manual-backup\runtime.mjs'),2),@(($script:Root+'\bin\runtime\scripts\manual-backup\runtime.mjs'),0x40000))){Require ([LdssBackupFoundation.Native]::Probe($api,$pair[0],[uint32]$pair[1]) -eq 5) 'API isolation failed for installed state.'}
  Require ([LdssBackupFoundation.Native]::Probe($worker,($script:Root+'\secrets\manual-backup.json'),1) -eq 0) 'Worker credential access failed.'
  $credential=[Management.Automation.PSCredential]::new(($env:COMPUTERNAME+'\ldss_ipu_bkp'),$workerPassword)
  New-Service -Name LDSSIPUATBackup -BinaryPathName ('"'+$script:Root+'\bin\manual-backup-service.exe"') -Credential $credential -StartupType Manual -DisplayName 'LDSS IP-UAT Manual Backup' | Out-Null;$serviceCreated=$true
  [LdssManualBackup.ServiceAccess]::SetAcl(('O:'+$Sid+'G:BAD:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;RC;;;OW)(A;;LC;;;'+$profile.apiSid+')'))
  Start-Service -Name LDSSIPUATBackup
  $proof=Verify-Service $profile $record;$record.phase='Installed';Save-Registration $record;return $proof
 }catch{
  if($serviceCreated){Stop-Service -Name LDSSIPUATBackup -ErrorAction SilentlyContinue}
  if($record){$record.phase='FailedStopped';Save-Registration $record}
  throw 'Worker installation refused or incomplete. Preserve protected receipts/configuration and inspect; no automatic retry, rollback or credential reset.'
 }finally{if($api){$api.Dispose()};if($worker){$worker.Dispose()};$workerPassword.Dispose();$adminPassword.Dispose()}
}
if($MyInvocation.InvocationName -ne '.') {Invoke-Install|ConvertTo-Json -Depth 6}
