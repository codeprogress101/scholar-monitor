# Function-only: no certificate-store installation, account change or backup-key access.
function New-IpcCertificates([string]$ServerDirectory,[string]$ClientDirectory){
 $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
 function Random-Bytes([int]$Length){$b=New-Object byte[] $Length;$rng.GetBytes($b);return ,$b}
 function New-Request([string]$Name,$Key,[bool]$Ca,[string]$Eku){
  $r=[Security.Cryptography.X509Certificates.CertificateRequest]::new(('CN='+$Name),$Key,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)
  $r.CertificateExtensions.Add([Security.Cryptography.X509Certificates.X509BasicConstraintsExtension]::new($Ca,$false,0,$true))
  $usage=if($Ca){[Security.Cryptography.X509Certificates.X509KeyUsageFlags]::KeyCertSign -bor [Security.Cryptography.X509Certificates.X509KeyUsageFlags]::CrlSign}else{[Security.Cryptography.X509Certificates.X509KeyUsageFlags]::DigitalSignature -bor [Security.Cryptography.X509Certificates.X509KeyUsageFlags]::KeyEncipherment}
  $r.CertificateExtensions.Add([Security.Cryptography.X509Certificates.X509KeyUsageExtension]::new($usage,$true))
  if($Eku){$oids=[Security.Cryptography.OidCollection]::new();[void]$oids.Add([Security.Cryptography.Oid]::new($Eku));$r.CertificateExtensions.Add([Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension]::new($oids,$true))}
  if($Name -eq 'ldss-ipuat-backup'){$san=[Security.Cryptography.X509Certificates.SubjectAlternativeNameBuilder]::new();$san.AddDnsName($Name);$san.AddIpAddress([Net.IPAddress]::Loopback);$r.CertificateExtensions.Add($san.Build())}
  return $r
 }
 function Pem($Cert){'-----BEGIN CERTIFICATE-----'+"`n"+[Convert]::ToBase64String($Cert.RawData,[Base64FormattingOptions]::InsertLineBreaks)+"`n-----END CERTIFICATE-----`n"}
 function Fingerprint($Cert){([BitConverter]::ToString($Cert.GetCertHash([Security.Cryptography.HashAlgorithmName]::SHA256))).Replace('-','').ToLowerInvariant()}
 function Write-NewBytes([string]$File,[byte[]]$Bytes){$s=[IO.File]::Open($File,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$s.Write($Bytes,0,$Bytes.Length);$s.Flush($true)}finally{$s.Dispose()}}
 $caKey=[Security.Cryptography.RSACng]::new(2048);$serverKey=[Security.Cryptography.RSACng]::new(2048);$clientKey=[Security.Cryptography.RSACng]::new(2048)
 $ca=$null;$server=$null;$client=$null
 try{
  $from=[DateTimeOffset]::UtcNow.AddMinutes(-5);$until=[DateTimeOffset]::UtcNow.AddDays(90)
  $ca=(New-Request 'ldss-ipuat-ipc-ca' $caKey $true '').CreateSelfSigned($from,$until.AddDays(1))
  $sn=Random-Bytes 16;$sn[0]=$sn[0] -band 0x7f;$sn[15]=$sn[15] -bor 1
  $issued=(New-Request 'ldss-ipuat-backup' $serverKey $false '1.3.6.1.5.5.7.3.1').Create($ca,$from,$until,$sn)
  try{$server=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::CopyWithPrivateKey($issued,$serverKey)}finally{$issued.Dispose()}
  $sn=Random-Bytes 16;$sn[0]=$sn[0] -band 0x7f;$sn[15]=$sn[15] -bor 1
  $issued=(New-Request 'ldss-ipuat-api' $clientKey $false '1.3.6.1.5.5.7.3.2').Create($ca,$from,$until,$sn)
  try{$client=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::CopyWithPrivateKey($issued,$clientKey)}finally{$issued.Dispose()}
  $serverPassword=[Convert]::ToBase64String((Random-Bytes 32));$clientPassword=[Convert]::ToBase64String((Random-Bytes 32))
  Write-NewBytes (Join-Path $ServerDirectory 'ipc-server.pfx') ($server.Export([Security.Cryptography.X509Certificates.X509ContentType]::Pfx,$serverPassword))
  Write-NewBytes (Join-Path $ClientDirectory 'ipc-client.pfx') ($client.Export([Security.Cryptography.X509Certificates.X509ContentType]::Pfx,$clientPassword))
  $serverConfig=@{version=1;port=3041;serverPfx=(Join-Path $ServerDirectory 'ipc-server.pfx');passphrase=$serverPassword;ca=(Pem $ca);clientFingerprint=(Fingerprint $client);expiresAt=$until.ToString('o')}
  $clientConfig=@{version=1;port=3041;clientPfx=(Join-Path $ClientDirectory 'ipc-client.pfx');passphrase=$clientPassword;ca=(Pem $ca);serverFingerprint=(Fingerprint $server);expiresAt=$until.ToString('o')}
  Write-NewBytes (Join-Path $ServerDirectory 'manual-backup-tls.json') ([Text.Encoding]::UTF8.GetBytes(($serverConfig|ConvertTo-Json -Compress)))
  Write-NewBytes (Join-Path $ClientDirectory 'api-client.json') ([Text.Encoding]::UTF8.GetBytes(($clientConfig|ConvertTo-Json -Compress)))
  return [ordered]@{transportCertificatesCreated=$true;expiresAt=$until.ToString('o');backupKeyRead=$false;certificateStoreModified=$false}
 }finally{if($ca){$ca.Dispose()};if($server){$server.Dispose()};if($client){$client.Dispose()};$caKey.Dispose();$serverKey.Dispose();$clientKey.Dispose();$rng.Dispose()}
}
