$ErrorActionPreference = 'Stop'
try {
    $handoff = [Console]::In.ReadToEnd() | ConvertFrom-Json
    $expires = [DateTimeOffset]::Parse($handoff.expiresAt)
    if ($expires -le [DateTimeOffset]::UtcNow -or $expires -gt [DateTimeOffset]::UtcNow.AddMinutes(16)) { throw 'Expired' }
    $uri = [Uri]$handoff.url
    if ($uri.Scheme -ne 'http' -or $uri.Host -ne '127.0.0.1' -or $uri.Port -notin @(5181,5182)) { throw 'Invalid origin' }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'LDSS - Private UAT password setup'
    $form.Size = New-Object System.Drawing.Size(650,250)
    $form.StartPosition = 'CenterScreen'
    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Point(16,15)
    $label.Size = New-Object System.Drawing.Size(600,65)
    $label.Text = "Private one-time setup for $($handoff.email).`r`nDeliver only to the verified account owner. Expires $($expires.ToOffset([TimeSpan]::FromHours(8)).ToString('yyyy-MM-dd HH:mm:ss')) Philippine time."
    $text = New-Object System.Windows.Forms.TextBox
    $text.Location = New-Object System.Drawing.Point(16,90)
    $text.Size = New-Object System.Drawing.Size(600,55)
    $text.Multiline = $true
    $text.ReadOnly = $true
    $text.Text = $handoff.url
    $close = New-Object System.Windows.Forms.Button
    $close.Location = New-Object System.Drawing.Point(500,160)
    $close.Size = New-Object System.Drawing.Size(116,36)
    $close.Text = 'Close'
    $close.Add_Click({ $form.Close() })
    $form.Controls.AddRange(@($label,$text,$close))
    $form.CancelButton = $close
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 1000
    $timer.Add_Tick({ if ([DateTimeOffset]::UtcNow -ge $expires) { $form.Close() } })
    $form.Add_Shown({ $timer.Start(); $text.Focus() })
    $form.Add_FormClosed({ $timer.Stop(); $text.Text = ''; $handoff.url = ''; $timer.Dispose() })
    [void]$form.ShowDialog()
    $form.Dispose()
} catch { exit 1 }
