import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import mysql from 'mysql2/promise';
import {createBackup,restoreBackup,unseal} from './backup-lib.mjs';
import {schemaDigest} from './manual-backup/source-meta.mjs';
import {createRuntime} from './manual-backup/runtime.mjs';
import {buildApp} from '../server/app.ts';
import {loadConfig} from '../server/config.ts';
import {AuthService} from '../server/auth/service.ts';
import {AuthorizationService} from '../server/authorization/service.ts';
const out=path.resolve('../fixture-'+randomBytes(4).toString('hex'));await fs.mkdir(out,{recursive:false});await fs.mkdir(out+'/private');
execFileSync('icacls.exe',[out+'/private','/inheritance:r','/grant:r','ADMIN:(OI)(CI)F','SYSTEM:(OI)(CI)F'],{windowsHide:true,stdio:'pipe'});
const source='ldss_restore_1793167108097_2b47a744',admin={host:'127.0.0.1',port:3306,user:'root',password:process.env.LDSS_SETUP_ADMIN_PASSWORD,timezone:'Z',jsonStrings:true};
const key=randomBytes(32),hash=x=>createHash('sha256').update(x).digest('hex'),results=[];
let target,definer,workerUser,sql,runtime,app,pool,phase="operator-preflight";
const pass=name=>{results.push(name);console.log('PASS '+name);};
try{
 const admissionProbe=await mysql.createConnection(admin);try{const [[identity]]=await admissionProbe.query('SELECT CURRENT_USER() account_name,@@hostname host_name');assert.equal(identity.account_name,'root@localhost');assert.equal(identity.host_name,'DESKTOP-BPLJKRP');}finally{await admissionProbe.end();}
 phase='native-client-integrity';const baseline=JSON.parse(await fs.readFile('C:/Users/ADMIN/.ldss/ip-uat-1-20261028/baseline/seed-complete.json','utf8'));
 const client=baseline.client;assert.equal(hash(await fs.readFile(client.path)),client.sha256);
 const context={connection:{...admin,database:source},directory:out+'/private',dumpTool:'C:/xampp/mysql/bin/mysqldump.exe',args:['--no-defaults','--host=127.0.0.1','--port=3306','--user=root','--default-character-set=utf8mb4']};
 phase="source-copy-and-isolated-restore";const copyArchive=await createBackup(key,context),copy=await restoreBackup(copyArchive.file,key,{keep:true,context:{sourceDatabase:source,admin,binaryMysqlTool:client.path,directory:out+'/private'}});
 target=copy.target;const copyReport=JSON.parse(await fs.readFile(copy.reportFile,'utf8'));definer=copyReport.definerAccount;assert.ok(copyReport.verified&&copyReport.tables.length===149);pass('Fresh BACKUP-1 copy: complete 149-table isolated restoration');
 assert.notEqual(target,source);sql=await mysql.createConnection({...admin,database:target});
 const [originalPayments]=await sql.query('SELECT * FROM payment_records ORDER BY id'),paymentHash=hash(JSON.stringify(originalPayments));
 workerUser='ldss_bkw_'+randomBytes(6).toString('hex');const workerPassword=randomBytes(32).toString('base64url');
 await sql.query('CREATE USER ?@\'localhost\' IDENTIFIED BY ?',[workerUser,workerPassword]);
 await sql.query(`GRANT SELECT,SHOW VIEW,LOCK TABLES,TRIGGER,EVENT,ALTER ROUTINE ON \`${target}\`.* TO ?@'localhost'`,[workerUser]);
 const scoped=await mysql.createConnection({...admin,database:target,user:workerUser,password:workerPassword});
 try{
  await assert.rejects(scoped.query('SELECT * FROM ldss_primary_test_12676_61497616.users LIMIT 1'));
  await assert.rejects(scoped.query('UPDATE users SET version=version WHERE 1=0'));
  await assert.rejects(scoped.query('CREATE TABLE unauthorized_probe(id INT)'));pass('Source worker denied primary reads, source DML and table DDL');
  await sql.query('CREATE PROCEDURE manual_backup_probe() SQL SECURITY INVOKER SELECT 1');
  await sql.query("CREATE EVENT manual_backup_probe_event ON SCHEDULE AT CURRENT_TIMESTAMP + INTERVAL 1 DAY DISABLE DO SELECT 1");
  const [[metadata]]=await scoped.query('SELECT (SELECT COUNT(*) FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA=DATABASE()) routines_n,(SELECT COUNT(*) FROM information_schema.EVENTS WHERE EVENT_SCHEMA=DATABASE()) events_n,(SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()) triggers_n');
  assert.equal(Number(metadata.routines_n),1);assert.equal(Number(metadata.events_n),1);assert.equal(Number(metadata.triggers_n),33);pass('Source-scoped metadata visibility includes 33 triggers and unexpected routine/event');
  await sql.query('DROP PROCEDURE manual_backup_probe');await sql.query('DROP EVENT manual_backup_probe_event');
 }finally{await scoped.end();}
 pool=mysql.createPool({...admin,database:target,connectionLimit:8});
 const config=loadConfig({APP_ENV:'test',APP_ORIGIN:'http://127.0.0.1:3026',PORT:'3026'});
 const auth=new AuthService(pool),roles=new AuthorizationService(pool),actors={};
 for(const role of['system_admin','staff','coordinator']){const email='manual-backup-'+role+'-'+randomBytes(3).toString('hex')+'@example.invalid',id=await auth.createAccount('Fictional backup '+role,email,'manual-backup-fixture'),token=await auth.issueReset(email,'manual-backup-fixture','Owned backup authorization test'),password=randomBytes(24).toString('base64url');await auth.resetPassword(token,password,'127.0.0.1',randomUUID());await roles.setRoles({email,roles:[role],expectedVersion:2,requestId:randomUUID(),operator:'manual-backup-fixture',reason:'Owned synthetic backup role'});actors[role]={id,email,password};}
 const [journal]=await sql.query('SELECT version,checksum FROM schema_migrations ORDER BY version');
 const workerConfig={connection:{...admin,database:target,user:workerUser,password:workerPassword},host:'DESKTOP-BPLJKRP',schemaHash:schemaDigest(unseal(await fs.readFile(copyArchive.file),key,source).inventory),journalHash:hash(JSON.stringify(journal)),releaseHash:'f'.repeat(64),objects:{tables:149,views:3,triggers:33,routines:0,events:0},jobs:out+'/private/jobs',archives:out+'/private/archives',dumpTool:'C:/xampp/mysql/bin/mysqldump.exe'};
 runtime=await createRuntime(workerConfig,key);
 app=buildApp(config,{logger:false,database:{pool,check:async()=> 'connected',close:async()=>{}},backupTransport:r=>runtime.worker.request(r)});
 const request=(role,route,body,keyValue=randomUUID())=>{const a=actors[role];return app.inject({method:body?'POST':'GET',url:'/api/v1/'+route,headers:{cookie:a.cookie,origin:config.APP_ORIGIN,...(body?{'content-type':'application/json','x-csrf-token':a.csrf,'idempotency-key':keyValue}:{})},...(body?{payload:body}:{})});};
 for(const role of Object.keys(actors)){const a=actors[role],r=await app.inject({method:'POST',url:'/api/v1/auth/login',headers:{origin:config.APP_ORIGIN,'content-type':'application/json'},payload:{email:a.email,password:a.password}});assert.equal(r.statusCode,200,r.body);a.cookie=String(r.headers['set-cookie']).split(';')[0];a.csrf=r.json().csrfToken;}
 for(const role of['staff','coordinator'])assert.equal((await request(role,'admin/backups')).statusCode,403);pass('Staff and Coordinator denied actual backup endpoints');
 const availability=await request('system_admin','admin/backups/availability');assert.equal(availability.statusCode,200,availability.body);const sourceVersion=availability.json().sourceVersion;assert.match(sourceVersion,/^[a-f0-9]{64}$/);
 const body={reason:'Disposable full encrypted backup acceptance',confirmed:true,sourceVersion},commandKey=randomUUID();
 const pair=await Promise.all([request('system_admin','admin/backups',body,commandKey),request('system_admin','admin/backups',body,commandKey)]);assert.equal(pair[0].statusCode,200,pair[0].body);assert.equal(pair[1].statusCode,200,pair[1].body);const id=pair[0].json().id;assert.equal(id,pair[1].json().id);await runtime.worker.idle();
 const committed=await request('system_admin','admin/backups/'+id);assert.equal(committed.statusCode,200);assert.equal(committed.json().state,'authenticated',committed.body);assert.equal(committed.json().tables,149);pass('Concurrent duplicate admission: one complete encrypted job and source audit');
 const retry=await request('system_admin','admin/backups',body,commandKey);assert.equal(retry.statusCode,200,retry.body);assert.equal(retry.json().id,id);assert.equal(retry.json().state,'authenticated');assert.equal((await request('system_admin','admin/backups',{...body,reason:'Changed request'},commandKey)).statusCode,409);pass('Lost response/exact replay returns original job; changed payload rejected');
 const job=await runtime.store.load(id),file=path.join(workerConfig.archives,id,job.archive.file),restored=await restoreBackup(file,key,{context:{sourceDatabase:target,admin,binaryMysqlTool:client.path,directory:out+'/private'}});const proof=JSON.parse(await fs.readFile(restored.reportFile,'utf8'));assert.ok(proof.verified&&proof.tables.length===149);pass('Worker archive: all 149 tables, triggers, views, values, accounts and payment evidence restored completely');
 const tampered=Buffer.from(await fs.readFile(file));tampered[tampered.length-1]^=1;assert.throws(()=>unseal(tampered,key,target));assert.throws(()=>unseal(awaitValue(),key,target));function awaitValue(){return Buffer.alloc(1);}pass('Archive corruption/truncation rejected');
 assert.equal(hash(JSON.stringify((await sql.query('SELECT * FROM payment_records ORDER BY id'))[0])),paymentHash);pass('All copied original payment rows/dates preserved around backup tests');
 const [[counts]]=await sql.query("SELECT COUNT(*) n FROM audit_logs WHERE event_type='backup.requested' AND entity_id=?",[id]);assert.equal(Number(counts.n),1);
 await fs.writeFile(out+'/result.json',JSON.stringify({passed:results.length,groups:results,sourceNotRestored:source,target,sourceMetadataDdlAuthority:['TRIGGER','EVENT','ALTER ROUTINE'],osServiceOrProtectedKeyTested:false},null,2),{flag:'wx'});
 // Preserve a disposable browser fixture until the task's later explicit cleanup.
 await fs.writeFile(out+'/private/fixture.json',JSON.stringify({target,definer,workerUser,workerConfig,actors,key:key.toString('base64'),client},null,2),{flag:'wx'});
 console.log(JSON.stringify({groups:results.length,fixtureRetained:true,output:out}));
}catch(e){console.error(JSON.stringify({phase,code:e.code??'FAILURE',assertion:e.code==='ERR_ASSERTION'?e.message:undefined,output:out}));process.exitCode=1;
 // Failed fixtures are retained with owned identity metadata for safe task cleanup.
 await fs.writeFile(out+'/private/failed-owned.json',JSON.stringify({target,definer,workerUser}),{flag:'wx'});
}finally{if(runtime)await runtime.close();if(app)await app.close();if(pool)await pool.end();if(sql)await sql.end();key.fill(0);}
