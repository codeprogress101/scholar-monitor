/** Guarded compatibility bootstrap. Original DDL actually executes on owned 10.4, not 11.4. */
import mysql from 'mysql2/promise';
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createBackup,loadKey,unseal,run,inventory} from '../backup-lib.mjs';
import {applyForward} from './f58-forward.mjs';
export async function provisionTarget(connection,options,applyOriginal){
 const [[actual]]=await connection.query('SELECT DATABASE() name,@@port port,@@version version,@@datadir datadir');
 assert.equal(actual.port,3337);assert.match(actual.version,/^11\.4\.13-/);assert.match(actual.datadir,/db-compat-2-20261028[\\/]runtime-one[\\/]data[\\/]?$/i);
 assert.match(actual.name,new RegExp('^ldss_[a-z0-9_]+_test_'+process.pid+'_[a-f0-9]{8}$'));
 const [tables]=await connection.query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()');
 if(tables.length)return applyOriginal(connection,options);
 assert.equal(Object.keys(options).length,0,'Partial historic DDL requires separate rehearsal');
 const admin={jsonStrings:true,host:'127.0.0.1',port:3306,user:'root',password:process.env.LDSS_DB_COMPAT_SOURCE_PASSWORD??'',timezone:'Z'},source=await mysql.createConnection(admin);let made=false;
 const dir=process.env.LDSS_DB_COMPAT_EVIDENCE;assert.ok(dir);const started=performance.now();
 try{
  const [[exists]]=await source.query('SELECT COUNT(*) n FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=?',[actual.name]);assert.equal(exists.n,0);await source.query('CREATE DATABASE `'+actual.name+'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');made=true;await source.changeUser({database:actual.name});
  const applied=await applyOriginal(source,options);assert.equal(applied.length,67);
  const baseline=await inventory(source);
  await applyForward(source,{database:actual.name,baseline,journalFile:dir+'/f58-'+process.pid+'.jsonl'});
  const vendor='C:/Users/ADMIN/.ldss/db-compat-2-20261028/vendor/mariadb-11.4.13-winx64/bin/';
  const backup=await createBackup(await loadKey(),{connection:{...admin,database:actual.name},directory:dir+'/bootstrap',dumpTool:vendor+'mariadb-dump.exe',args:['--no-defaults','--host=127.0.0.1','--port=3306','--user=root','--default-character-set=utf8mb4']});
  const payload=unseal(await readFile(backup.file),await loadKey(),actual.name),sql=payload.sql.replace(/^\/\*!\d{5}[^\r\n]*$/gm,l=>l.replace(/DEFINER=`(?:[^`]|``)*`@`(?:[^`]|``)*`/g,'DEFINER=CURRENT_USER'));
  await run(vendor+'mariadb.exe',['--no-defaults','--host=127.0.0.1','--port=3337','--user=root','--default-character-set=utf8mb4','--binary-mode','--local-infile=0',actual.name],{input:sql,password:process.env.LDSS_SETUP_ADMIN_PASSWORD});
  assert.deepEqual(await inventory(connection),payload.inventory);
  await writeFile(dir+'/bootstrap-'+process.pid+'.json',JSON.stringify({passed:true,model:'compatibility-bootstrap/v2',originalMigrationsActuallyExecutedOn3306:67,forwardExecutedOn3306:true,targetPort:3337,originalJournalTransferredExactly:true,tables:148,migrations:68,zeroScholars:payload.inventory.tables.find(t=>t.name==='scholars').count===0,zeroPayments:payload.inventory.tables.find(t=>t.name==='payment_records').count===0,seconds:(performance.now()-started)/1000,nativeDirectHistoricalExecutionOn11:false},null,2));return applied;
 }finally{try{if(made)await source.query('DROP DATABASE `'+actual.name+'`');}finally{await source.end();}}
}
