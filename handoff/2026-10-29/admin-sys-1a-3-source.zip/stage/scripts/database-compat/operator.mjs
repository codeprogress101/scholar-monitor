/** Explicit isolated operator entry; primary/operational targets are not admitted. */
import mysql from 'mysql2/promise';import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
import {applyForward} from './f58-forward.mjs';
const args=process.argv.slice(2);assert.equal(args.length,1,'Supply one private reviewed plan filename');
const bytes=await readFile(args[0]);assert.ok(bytes.length<=32768);const plan=JSON.parse(bytes);
assert.equal(plan.contract,'DB-COMPAT-2/isolated-forward-v1');assert.equal(plan.host,'127.0.0.1');
assert.notEqual(plan.database,'ldss_primary_test_12676_61497616');assert.match(plan.database,/^ldss_restore_\d+_[a-f0-9]{8}$/);
assert.ok([3306,3337,3338].includes(plan.port));assert.match(plan.version,/^(10\.4\.32|11\.4\.13)-MariaDB$/);
const proof=JSON.parse(await readFile(plan.restoreReport,'utf8'));assert.ok(proof.verified&&proof.retained);assert.equal(proof.target,plan.database);assert.equal(proof.backupSha256,plan.backupSha256);
const baselineBytes=await readFile(plan.baselineFile);assert.equal(createHash('sha256').update(baselineBytes).digest('hex'),plan.baselineSha256);const baseline=JSON.parse(baselineBytes);
assert.ok([148,150].includes(baseline.tables.length));
const db=await mysql.createConnection({host:plan.host,port:plan.port,user:process.env.LDSS_COMPAT_OPERATOR_USER,password:process.env.LDSS_COMPAT_OPERATOR_PASSWORD??'',database:plan.database,jsonStrings:true,timezone:'Z',multipleStatements:false});
try{
 const [[id]]=await db.query('SELECT @@datadir datadir,@@version version,@@port port');assert.equal(id.datadir.replaceAll('\\','/').toLowerCase(),plan.datadir.replaceAll('\\','/').toLowerCase());assert.equal(id.version,plan.version);assert.equal(id.port,plan.port);
 const result=await applyForward(db,{database:plan.database,baseline,journalFile:plan.recoveryLog,expectedRuntime:{version:plan.version,port:plan.port}});
 console.log(JSON.stringify({completed:result.completed,noop:result.noop,version:result.version,checksum:result.checksum}));
}finally{await db.end();}
