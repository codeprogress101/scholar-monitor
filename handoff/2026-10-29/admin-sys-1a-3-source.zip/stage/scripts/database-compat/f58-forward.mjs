/** Isolated F58 forward runner. DDL commits independently; inspect, resume, never downgrade. */
import assert from 'node:assert/strict';
import {readFile,open,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {inventory} from '../backup-lib.mjs';
import {expressionChanges} from './f54-logical-transfer.mjs';
export const version='20261028010000_f58_generated_char_determinism.sql';
export const sha=x=>createHash('sha256').update(x).digest('hex');
export async function applyForward(db,{database,baseline,journalFile,expectedRuntime,onBoundary=async()=>{}}){
 assert.notEqual(database,'ldss_primary_test_12676_61497616');
 assert.ok(/^ldss_restore_\d+_[a-f0-9]{8}$/.test(database)||new RegExp('^ldss_[a-z0-9_]+_test_'+process.pid+'_[a-f0-9]{8}$').test(database),'Newly owned disposable target required');
 const [[id]]=await db.query('SELECT DATABASE() name,@@port port,@@version version');
 assert.equal(id.name,database);if(expectedRuntime){assert.equal(id.port,expectedRuntime.port);assert.equal(id.version,expectedRuntime.version);}assert.ok([3306,3337,3338].includes(id.port));assert.match(id.version,/^(?:10\.4\.32|11\.4\.13)-/);
 const sql=await readFile(new URL('../../db/proposed-migrations/'+version,import.meta.url),'utf8'),checksum=sha(sql),steps=sql.split(/\r?\n-- statement-break\r?\n/);assert.equal(steps.length,4);
 assert.equal(checksum,'40ddbc2e89e512e78d59dafa26779bb1c4cdcfaaa4168819d4811eb7f48d7a95','Unreviewed forward SQL');
 const folder=new URL('../../db/migrations/',import.meta.url),names=(await readdir(folder)).filter(x=>/^\d{14}_f\d{2}_[a-z_]+\.sql$/.test(x)).sort();assert.equal(names.length,67);
 const accepted=new Map(await Promise.all(names.map(async name=>[name,sha(await readFile(new URL(name,folder)))]))); 
 const originalJournal=baseline.tables.find(t=>t.name==='schema_migrations');assert.ok(originalJournal);
 const [[lock]]=await db.query('SELECT GET_LOCK(?,10) acquired',[database+':migrations']);assert.equal(lock.acquired,1);
 let log,previous='0'.repeat(64);
 try {
  log=await open(journalFile,'a');
  const prior=await readFile(journalFile,'utf8');
  for(const line of prior.trim().split('\n').filter(Boolean)){const row=JSON.parse(line),{hash,...content}=row;assert.equal(content.previous,previous);assert.equal(sha(JSON.stringify(content)),hash);previous=hash;}
 } catch(error){if(log)await log.close();await db.query('SELECT RELEASE_LOCK(?)',[database+':migrations']);throw error;}
 const record=async(event,details={})=>{const content={at:new Date().toISOString(),database,version,checksum,event,...details,previous};previous=sha(JSON.stringify(content));await log.write(JSON.stringify({...content,hash:previous})+'\n');await log.sync();};

 const compare=async()=>{
  const now=await inventory(db),expected=structuredClone(baseline);let prefix=0,missing=false;
  for(let step=0;step<4;step++){
   const group=step===0?[0]:step===1?[1,2]:step===2?[3]:[4];let corrected=0;
   for(const index of group){const[table,col,old,next]=expressionChanges[index],item=now.columns.find(c=>c.TABLE_NAME===table&&c.COLUMN_NAME===col);assert.ok(item);assert.ok([old,next].includes(item.GENERATION_EXPRESSION));if(item.GENERATION_EXPRESSION===next)corrected++;}
   assert.ok(corrected===0||corrected===group.length,'A statement may not be partly applied');
   if(corrected){assert.equal(missing,false,'Unexpected non-prefix schema');prefix++;for(const index of group){const[t,c,,next]=expressionChanges[index];expected.columns.find(x=>x.TABLE_NAME===t&&x.COLUMN_NAME===c).GENERATION_EXPRESSION=next;}}else missing=true;
  }
  const [history]=await db.query({sql:'SELECT * FROM schema_migrations ORDER BY version',rowsAsArray:true,dateStrings:true});const original=history.filter(r=>r[0]!==version);assert.equal(original.length,67);assert.equal(new Set(original.map(r=>r[0])).size,67);for(const row of original)assert.equal(accepted.get(row[0]),row[1],'Historical version/checksum is not accepted');assert.equal(sha(original.map(r=>sha(JSON.stringify(r))).sort().join('\n')),originalJournal.checksum);
  for(const row of history)if(row[0]===version){assert.equal(row[1],checksum);assert.equal(prefix,4);}
  now.tables=now.tables.filter(x=>x.name!=='schema_migrations');expected.tables=expected.tables.filter(x=>x.name!=='schema_migrations');assert.deepEqual(now,expected,'Unreviewed data/schema drift');
  return{prefix,completed:history.some(r=>r[0]===version)};
 };
 try{
  const initial=await compare();await record('verified-prefix',initial);if(initial.completed){await record('verified-complete-noop');return{completed:true,noop:true,checksum,version};}
  await onBoundary('before-first',initial.prefix);
  for(let i=initial.prefix;i<steps.length;i++){
   await record('before-alter',{step:i+1});await db.query(steps[i]);const state=await compare();assert.equal(state.prefix,i+1);await record('verified-alter',{step:i+1});await onBoundary('after-alter',i+1);
  }
  await onBoundary('verification',4);const final=await compare();assert.equal(final.prefix,4);await record('verified-all-values-and-constraints');
  await db.execute('INSERT INTO schema_migrations(version,checksum,applied_at) VALUES(?,?,UTC_TIMESTAMP(6))',[version,checksum]);
  await record('journal-committed');assert.equal((await compare()).completed,true);return{completed:true,noop:false,version,checksum};
 }catch(e){await record('stopped',{error:e.code??e.name});throw e;}
 finally{await log.close();await db.query('SELECT RELEASE_LOCK(?)',[database+':migrations']);}
}
