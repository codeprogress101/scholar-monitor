import {release} from './guard.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile,open} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {resolve} from 'node:path';
import {createServer} from 'node:net';

for(const key of ['LDSS_SETUP_ADMIN_PASSWORD','DB_PASSWORD'])assert.ok(!(key in process.env),'Operator credentials must not be inherited');
const settingsPath=resolve(process.argv[2]),settings=JSON.parse(await readFile(settingsPath,'utf8'));
const manifest=JSON.parse(await readFile(resolve(release,'runtime-manifest.json'),'utf8'));
if(settings.mode==='primary') {
  assert.equal(manifest.primaryActivationAllowed,true,'Primary activation gate is not satisfied');
  const gatePath=resolve(release,'dependency-gate.json');
  assert.equal(createHash('sha256').update(await readFile(gatePath)).digest('hex'),manifest.dependencyGateHash,'Dependency verification proof changed');
  const gate=JSON.parse(await readFile(gatePath,'utf8'));
  assert.equal(gate.passed,true,'Dependency identity and audit gates failed');
  assert.equal(gate.installs.length,2,'Two independent installation proofs required');
  assert.equal(gate.independentEmptyCaches,2,'Two independent installations required');
  assert.equal(gate.registryArtifactsVerified,true,'Registry artifact verification required');
  for(const proof of gate.installs) {
    assert.equal(proof.passed,true); assert.equal(proof.cacheInitiallyEmpty,true);
    for(const label of ['ci','tree','audit-production','audit-full','cache-verify'])assert.equal(proof.commands.find(x=>x.label===label)?.exitCode,0,'Dependency gate: '+label);
  }
  assert.notEqual(gate.installs[0].cache,gate.installs[1].cache);
  for(const [name,hash] of Object.entries(gate.manifestAndLockHashes))assert.equal(createHash('sha256').update(await readFile(resolve(release,name))).digest('hex'),hash,name+' changed after verification');
}
let next=0;
await Promise.all(Array.from({length:8},async()=>{while(next<manifest.files.length){const item=manifest.files[next++];assert.equal(createHash('sha256').update(await readFile(resolve(release,item.path))).digest('hex'),item.sha256,item.path);}}));
assert.equal(manifest.environmentHash,createHash('sha256').update(JSON.stringify(settings.environment)).digest('hex'));
assert.ok(settings.mode==='primary'||settings.mode==='owned-rehearsal');
assert.deepEqual([settings.apiPort,settings.webPort],settings.mode==='primary'?[3001,5173]:[3026,3028]);
for(const port of [settings.apiPort,settings.webPort]) await new Promise((ok,no)=>{const s=createServer();s.once('error',no);s.listen({host:'127.0.0.1',port,exclusive:true},()=>s.close(ok));});
const children=[],handles=[],started=performance.now();
const childEnvironment=Object.fromEntries(Object.entries(process.env).filter(([key])=>['SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','COMPUTERNAME','PATHEXT','USERPROFILE','LOCALAPPDATA','APPDATA'].includes(key.toUpperCase())));
childEnvironment.PATH=resolve(release,'bin')+';'+resolve(process.env.SystemRoot||'C:/Windows','System32');
let stopping=false;
function stop() { if(stopping)return; stopping=true;for(const child of children)child.kill(); }
async function child(name) {
 const log=await open(settings.stateDirectory+'/'+name+'.log','a');handles.push(log);
 const p=spawn(process.execPath,[resolve(release,'scripts/isolated-primary/'+name+'.mjs'),settingsPath],{cwd:release,env:childEnvironment,windowsHide:true,stdio:['ignore',log.fd,log.fd]});children.push(p);
 p.on('error',()=>{stop();process.exitCode=1;});
 p.on('exit',code=>{if(!stopping){stop();process.exitCode=code||1;}});
 return p;
}
async function ready(port,path) {
 for(let n=0;n<160;n++) {if(stopping)throw Error('Runtime child stopped');try{if((await fetch('http://127.0.0.1:'+port+path,{signal:AbortSignal.timeout(2000)})).status===200)return;}catch{ /* bounded startup retry */ }await new Promise(ok=>setTimeout(ok,250));}
 throw Error('Dedicated runtime readiness failed');
}
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,stop);
try {
 const api=await child('api');await ready(settings.apiPort,'/api/v1/ready');
 const web=await child('web');await ready(settings.webPort,'/api/v1/ready');
 await writeFile(settings.stateDirectory+'/running-profile.json',JSON.stringify({profile:'synthetic-isolated-authrel3',controllerPid:process.pid,apiPid:api.pid,webPid:web.pid,release,settingsPath,startedAt:new Date().toISOString(),readyMs:performance.now()-started},null,2));
 console.log('Dedicated synthetic runtime ready');
} catch(error) {stop();process.exitCode=1;throw error;}
process.on('exit',()=>{for(const h of handles)void h.close();});
